"use client";

import Lenis from "lenis";
import {
  createContext,
  useContext,
  useEffect,
  useState,
  type ReactNode,
} from "react";
import { gsap, ScrollTrigger } from "./gsap";
import { prefersReducedMotion } from "./device";

const LenisContext = createContext<Lenis | null>(null);

/** Exposes the live Lenis instance so components can call .start()/.stop() (e.g. the Loader). */
export function useLenis() {
  return useContext(LenisContext);
}

export function LenisProvider({ children }: { children: ReactNode }) {
  const [lenis, setLenis] = useState<Lenis | null>(null);

  useEffect(() => {
    const reduced = prefersReducedMotion();

    const instance = new Lenis({
      duration: reduced ? 0.1 : 1.2,
      smoothWheel: !reduced,
      touchMultiplier: 1.4,
      autoRaf: false,
    });

    // Held stopped until the Loader hands off control.
    instance.stop();

    instance.on("scroll", ScrollTrigger.update);

    const tick = (time: number) => {
      instance.raf(time * 1000);
    };
    gsap.ticker.add(tick);
    gsap.ticker.lagSmoothing(0);

    setLenis(instance);

    return () => {
      gsap.ticker.remove(tick);
      instance.destroy();
    };
  }, []);

  return (
    <LenisContext.Provider value={lenis}>{children}</LenisContext.Provider>
  );
}
