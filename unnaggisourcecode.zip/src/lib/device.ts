/** Pure capability checks — safe to call in effects, never during SSR render. */

export function prefersReducedMotion(): boolean {
  if (typeof window === "undefined") return false;
  return window.matchMedia("(prefers-reduced-motion: reduce)").matches;
}

export function supportsWebGL(): boolean {
  if (typeof window === "undefined") return false;
  try {
    const canvas = document.createElement("canvas");
    return !!(
      canvas.getContext("webgl2") || canvas.getContext("webgl")
    );
  } catch {
    return false;
  }
}

export function isTouchDevice(): boolean {
  if (typeof window === "undefined") return false;
  return window.matchMedia("(pointer: coarse)").matches;
}

export function isDesktopViewport(): boolean {
  if (typeof window === "undefined") return false;
  return window.matchMedia("(min-width: 768px)").matches;
}

/** Gate for the one R3F moment: only mount it when it can genuinely add value. */
export function canUseAperture3D(): boolean {
  return (
    !prefersReducedMotion() &&
    isDesktopViewport() &&
    !isTouchDevice() &&
    supportsWebGL()
  );
}
