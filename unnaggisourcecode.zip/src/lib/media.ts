import type { MediaRef } from "@/content/types";

/** Narrows a MediaRef to one that actually points at a real asset. */
export function hasRealSource(
  media: MediaRef | undefined
): media is MediaRef & { src: string } {
  return !!media?.src;
}
