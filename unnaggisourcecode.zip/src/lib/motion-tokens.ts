/**
 * Single source of truth for UNNAGGI's motion + color language.
 * GSAP, Framer Motion and the generative canvas/SVG visuals all read from here
 * so the "cinematic" feel stays consistent across every animation engine in use.
 */

export const colors = {
  navy: "#0B0A18",
  almostBlack: "#050409",
  ivory: "#F5F2EB",
  gold: "#D8B26E",
  graphite: "#3A3A42",
  softGray: "#8B8B94",
} as const;

/** GSAP eases (GSAP's own ease-string syntax). */
export const gsapEase = {
  cinematic: "power4.out",
  cinematicInOut: "power3.inOut",
  shutter: "expo.inOut",
  reveal: "power2.out",
  elastic: "elastic.out(1, 0.4)",
  linear: "none",
} as const;

/** Framer Motion cubic-bezier eases (same visual language as gsapEase, different syntax). */
export const framerEase = {
  cinematic: [0.16, 1, 0.3, 1] as [number, number, number, number],
  shutter: [0.83, 0, 0.17, 1] as [number, number, number, number],
  reveal: [0.22, 1, 0.36, 1] as [number, number, number, number],
} as const;

export const durations = {
  fast: 0.4,
  base: 0.8,
  slow: 1.4,
  loader: 2.4,
} as const;

/** Shared mood-tint palette — the generative "set lighting" used anywhere a mood needs a color. */
export const moodTint = {
  cool: "#1b2340",
  warm: "#3a2a18",
  flash: "#3a3a42",
  neutral: "#15141f",
} as const;

/** Total chapters in the Hero reel, used to size the pinned scroll track. */
export const HERO_CHAPTER_COUNT = 11;

/** vh per chapter — tuned so an average scroll pace clears the reel in ~20-30s. */
export const HERO_VH_PER_CHAPTER = 100;
export const HERO_CLOSING_VH = 120;
