"use client";

import { useState } from "react";
import { Loader } from "@/components/loader/Loader";
import { Hero } from "@/components/hero/Hero";
import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";
import { ProductionJourney } from "@/components/journey/ProductionJourney";
import { FeaturedFilms } from "@/components/work/FeaturedFilms";
import { Services } from "@/components/services/Services";
import { WhyUnnaggi } from "@/components/why/WhyUnnaggi";
import { BehindTheScenes } from "@/components/bts/BehindTheScenes";
import { Clients } from "@/components/clients/Clients";
import { Testimonials } from "@/components/testimonials/Testimonials";
import { Awards } from "@/components/awards/Awards";
import { Studio } from "@/components/studio/Studio";
import { Contact } from "@/components/contact/Contact";
import { SITE } from "@/content/site";

export default function Home() {
  const [loaderDone, setLoaderDone] = useState(false);

  return (
    <main>
      <h1 className="sr-only">
        {SITE.name} — {SITE.tagline}
      </h1>
      <Loader onComplete={() => setLoaderDone(true)} />
      <Header visible={loaderDone} />
      <Hero />
      <ProductionJourney />
      <FeaturedFilms />
      <Services />
      <WhyUnnaggi />
      <BehindTheScenes />
      <Clients />
      <Testimonials />
      <Awards />
      <Studio />
      <Contact />
      <Footer />
      {loaderDone && (
        <span className="sr-only" role="status">
          UNNAGGI has loaded
        </span>
      )}
    </main>
  );
}
