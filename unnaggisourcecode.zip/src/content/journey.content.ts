import type { JourneyStage } from "./types";

export const JOURNEY_STAGES: JourneyStage[] = [
  {
    id: "discover",
    index: 1,
    title: "Discover",
    description:
      "We start inside the brand, not outside it — understanding the audience, the ambition, and the moment this film needs to land in.",
  },
  {
    id: "design",
    index: 2,
    title: "Design",
    description:
      "Script, storyboard, mood, and shot list — every creative decision made before a single light is switched on.",
  },
  {
    id: "produce",
    index: 3,
    title: "Produce",
    description:
      "On set or in the studio, our crew moves as one unit — camera, lighting, and direction working from a single vision.",
  },
  {
    id: "deliver",
    index: 4,
    title: "Deliver",
    description:
      "Edit, grade, sound, and motion graphics finished in-house, delivered ready for the platform it was built for.",
  },
];
