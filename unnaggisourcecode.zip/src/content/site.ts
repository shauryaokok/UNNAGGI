import type { SiteConfig } from "./types";

export const SITE: SiteConfig = {
  name: "UNNAGGI",
  tagline: "We Are Never On A Break.",
  description:
    "UNNAGGI is a premium film production house crafting commercial films, luxury brand films, automotive commercials, fashion films and unforgettable visual experiences.",
  url: "https://unnaggi.com",
};
