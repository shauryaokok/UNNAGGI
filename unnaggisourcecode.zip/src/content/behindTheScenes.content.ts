import type { BehindTheScenesFrame } from "./types";

export const BTS_FRAMES: BehindTheScenesFrame[] = [
  { id: "lighting-rig", caption: "Lighting the set", mood: "warm" },
  { id: "camera-dept", caption: "Camera department", mood: "cool" },
  { id: "director-monitor", caption: "Reviewing the take", mood: "neutral" },
  { id: "edit-bay", caption: "In the edit bay", mood: "neutral" },
  { id: "color-suite", caption: "Color session", mood: "flash" },
  { id: "location-scout", caption: "Location scout", mood: "cool" },
  { id: "sound-stage", caption: "On the sound stage", mood: "warm" },
  { id: "crew-briefing", caption: "Morning briefing", mood: "neutral" },
];
