import type { HeroChapterContent } from "./types";

/**
 * The Hero reel. No `media.src` is set on any chapter — every chapter renders its
 * generative visual by default. Drop a real `src` into any entry below (video or image)
 * once real UNNAGGI footage exists; the VideoLayer picks it up with no component changes.
 */
export const HERO_CHAPTERS: HeroChapterContent[] = [
  {
    id: "idea",
    index: 1,
    headline: "Idea",
    microcopy: "Every frame begins with a single thought.",
    mood: "cool",
  },
  {
    id: "script",
    index: 2,
    headline: "Script",
    microcopy: "The story finds its words before it finds its shot.",
    mood: "cool",
  },
  {
    id: "storyboard",
    index: 3,
    headline: "Storyboard",
    microcopy: "A sketch of the film that doesn't exist yet.",
    mood: "neutral",
  },
  {
    id: "pre-production",
    index: 4,
    headline: "Pre-Production",
    microcopy: "Every detail decided before a single frame is shot.",
    mood: "neutral",
  },
  {
    id: "lights",
    index: 5,
    headline: "Lights",
    microcopy: "We build the world the story lives in.",
    mood: "warm",
  },
  {
    id: "camera",
    index: 6,
    headline: "Camera",
    microcopy: "The eye through which the story is told.",
    mood: "warm",
  },
  {
    id: "action",
    index: 7,
    headline: "Action",
    microcopy: "The moment everything comes alive.",
    mood: "warm",
  },
  {
    id: "edit",
    index: 8,
    headline: "Edit",
    microcopy: "Rhythm is where the story is truly written.",
    mood: "neutral",
  },
  {
    id: "color-grading",
    index: 9,
    headline: "Color Grading",
    microcopy: "Every frame, tuned until it feels inevitable.",
    mood: "flash",
  },
  {
    id: "motion-graphics",
    index: 10,
    headline: "Motion Graphics",
    microcopy: "Where design learns to move.",
    mood: "cool",
  },
  {
    id: "final-film",
    index: 11,
    headline: "Final Film",
    microcopy: "The story, finally ready to be seen.",
    mood: "warm",
  },
];

export const HERO_CLOSING = {
  headline: "We Are Never On A Break.",
  microcopy: "UNNAGGI — a premium film production house.",
  ctaLabel: "Enter The Studio",
};
