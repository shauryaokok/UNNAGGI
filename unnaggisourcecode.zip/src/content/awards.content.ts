import type { Award } from "./types";

export const AWARDS: Award[] = [
  { id: "aw-1", title: "Best Automotive Film", organization: "Cannes Lions", year: 2025 },
  { id: "aw-2", title: "Gold — Fashion Film", organization: "Vimeo Staff Pick", year: 2025 },
  { id: "aw-3", title: "Best Direction", organization: "UK Music Video Awards", year: 2024 },
  { id: "aw-4", title: "Grand Prix — Branded Content", organization: "D&AD", year: 2024 },
  { id: "aw-5", title: "Best Cinematography", organization: "Berlin Commercial Awards", year: 2023 },
  { id: "aw-6", title: "Silver — CGI & Visual Effects", organization: "Clio Awards", year: 2023 },
];
