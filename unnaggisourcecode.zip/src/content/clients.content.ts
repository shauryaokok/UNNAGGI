import type { Client } from "./types";

export const CLIENTS: Client[] = [
  { id: "velocare", name: "Velocare Motors" },
  { id: "maison-ferro", name: "Maison Ferro" },
  { id: "chateau-salvane", name: "Château Salvane" },
  { id: "norr", name: "Norr Architecture" },
  { id: "ledger", name: "Ledger & Co." },
  { id: "solstice", name: "Solstice Watches" },
  { id: "aurea", name: "Aurea Beauty" },
  { id: "kessel", name: "Kessel Group" },
  { id: "novara", name: "Novara Studios" },
  { id: "petraq", name: "Petraq Jewellery" },
];
