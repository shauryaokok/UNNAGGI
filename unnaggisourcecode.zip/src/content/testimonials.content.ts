import type { Testimonial } from "./types";

export const TESTIMONIALS: Testimonial[] = [
  {
    id: "velocare",
    quote: "UNNAGGI didn't just shoot our launch film — they directed the way we think about the brand on screen.",
    name: "Elina Voss",
    role: "CMO, Velocare Motors",
  },
  {
    id: "maison-ferro",
    quote: "Every frame felt considered. It's rare to hand something over and get back exactly the film you imagined, only better.",
    name: "Daniel Ferro",
    role: "Creative Director, Maison Ferro",
  },
  {
    id: "chateau-salvane",
    quote: "They were never on a break, and it showed — revisions came back overnight, and every one was sharper than the last.",
    name: "Marguerite Salvane",
    role: "Owner, Château Salvane",
  },
];
