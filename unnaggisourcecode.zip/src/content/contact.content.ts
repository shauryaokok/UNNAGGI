export const CONTACT = {
  statement: "Have a story that can't wait?",
  ctaLabel: "Start A Project",
  email: "hello@unnaggi.com",
};
