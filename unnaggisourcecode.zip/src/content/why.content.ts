import type { WhyStatement } from "./types";

export const WHY_STATEMENTS: WhyStatement[] = [
  {
    id: "always-on",
    title: "We are never on a break.",
    description: "A dedicated crew on standby around the clock — the idea doesn't wait for business hours, so neither do we.",
  },
  {
    id: "in-house",
    title: "Everything, in-house.",
    description: "Camera, edit, grade, sound, motion graphics, and CGI — one team, one vision, zero handoff loss.",
  },
  {
    id: "one-contact",
    title: "One point of contact, start to finish.",
    description: "From the first idea to final delivery, you speak to the people actually making the film.",
  },
  {
    id: "craft",
    title: "Craft over trend.",
    description: "We build for the brief in front of us, not the algorithm of the week.",
  },
];
