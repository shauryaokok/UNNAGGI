import type { Project } from "./types";

/**
 * No `media.src` set on any entry — every poster renders its generative
 * treatment by default. Drop real footage/stills in per project when ready.
 */
export const PROJECTS: Project[] = [
  {
    id: "midnight-drive",
    title: "Midnight Drive",
    category: "Automotive",
    year: 2025,
    client: "Velocare Motors",
    synopsis: "A night-shot commercial built entirely around negative space and headlight trails.",
  },
  {
    id: "second-skin",
    title: "Second Skin",
    category: "Fashion",
    year: 2025,
    client: "Maison Ferro",
    synopsis: "A fabric-first fashion film shot at 1000fps to catch every fold in motion.",
  },
  {
    id: "the-vintage",
    title: "The Vintage",
    category: "Luxury Brand",
    year: 2024,
    client: "Château Salvane",
    synopsis: "An estate film treating a vineyard's harvest like a three-act structure.",
  },
  {
    id: "glass-house",
    title: "Glass House",
    category: "CGI",
    year: 2024,
    client: "Norr Architecture",
    synopsis: "A fully CGI walkthrough of an unbuilt structure, lit as if it already existed.",
  },
  {
    id: "proof-of-work",
    title: "Proof of Work",
    category: "Commercial",
    year: 2024,
    client: "Ledger & Co.",
    synopsis: "A campaign built from a single unbroken take across a working factory floor.",
  },
  {
    id: "afterglow",
    title: "Afterglow",
    category: "Luxury Brand",
    year: 2023,
    client: "Solstice Watches",
    synopsis: "A macro-lens study of light through sapphire crystal, cut to a heartbeat.",
  },
];
