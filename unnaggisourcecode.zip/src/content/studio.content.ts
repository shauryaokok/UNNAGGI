import type { StudioStat } from "./types";

export const STUDIO_MANIFESTO =
  "UNNAGGI is a small studio built to behave like a full production house — director, DP, editor, colorist, and motion designer, all under one roof, all on the same call sheet.";

export const STUDIO_STATS: StudioStat[] = [
  { id: "years", value: 9, suffix: "+", label: "Years in production" },
  { id: "films", value: 180, suffix: "+", label: "Films delivered" },
  { id: "awards", value: 12, label: "Industry awards" },
  { id: "countries", value: 14, label: "Countries shot in" },
];
