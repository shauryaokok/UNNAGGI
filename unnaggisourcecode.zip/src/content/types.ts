export type MediaKind = "video" | "image";

/** Points at a real asset. Omit `src` to fall back to the chapter's generative visual. */
export interface MediaRef {
  kind: MediaKind;
  src?: string;
  poster?: string;
  alt: string;
}

export type ChapterId =
  | "idea"
  | "script"
  | "storyboard"
  | "pre-production"
  | "lights"
  | "camera"
  | "action"
  | "edit"
  | "color-grading"
  | "motion-graphics"
  | "final-film";

/** Drives the LightingLayer's gradient/blend mood for a chapter. */
export type ChapterMood = "cool" | "warm" | "flash" | "neutral";

export interface HeroChapterContent {
  id: ChapterId;
  /** 1-based position, used for the "CH. 04 / 11" timecode readout. */
  index: number;
  headline: string;
  microcopy: string;
  mood: ChapterMood;
  media?: MediaRef;
}

export interface LoaderConfig {
  wordmark: string;
  cyclingWords: string[];
  /** Pacing floor so the sequence never feels rushed on a fast connection. */
  minDurationMs: number;
}

export interface SiteConfig {
  name: string;
  tagline: string;
  description: string;
  url: string;
}

export interface JourneyStage {
  id: string;
  index: number;
  title: string;
  description: string;
}

export type ProjectCategory =
  | "Commercial"
  | "Luxury Brand"
  | "Automotive"
  | "Fashion"
  | "CGI";

export interface Project {
  id: string;
  title: string;
  category: ProjectCategory;
  year: number;
  client: string;
  synopsis: string;
  media?: MediaRef;
}

export interface Service {
  id: string;
  index: number;
  title: string;
  description: string;
}

export interface WhyStatement {
  id: string;
  title: string;
  description: string;
}

export interface BehindTheScenesFrame {
  id: string;
  caption: string;
  mood: ChapterMood;
  media?: MediaRef;
}

export interface Client {
  id: string;
  name: string;
}

export interface Testimonial {
  id: string;
  quote: string;
  name: string;
  role: string;
}

export interface Award {
  id: string;
  title: string;
  organization: string;
  year: number;
}

export interface StudioStat {
  id: string;
  value: number;
  suffix?: string;
  label: string;
}
