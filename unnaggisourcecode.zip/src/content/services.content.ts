import type { Service } from "./types";

export const SERVICES: Service[] = [
  { id: "commercial-films", index: 1, title: "Commercial Films", description: "Campaign films built to hold attention on any screen, in any length." },
  { id: "luxury-brand-films", index: 2, title: "Luxury Brand Films", description: "Slow, deliberate storytelling for brands that don't need to shout." },
  { id: "automotive", index: 3, title: "Automotive Commercials", description: "Precision-timed motion, light, and sound for vehicles built to move." },
  { id: "fashion-films", index: 4, title: "Fashion Films", description: "Fabric, motion, and silhouette treated as the main character." },
  { id: "corporate-films", index: 5, title: "Corporate Films", description: "Institutional stories told with the same craft as a feature film." },
  { id: "photography", index: 6, title: "Photography", description: "Stills pulled from the same eye that shapes our motion work." },
  { id: "creative-direction", index: 7, title: "Creative Direction", description: "A single point of vision across every deliverable, every platform." },
  { id: "motion-graphics", index: 8, title: "Motion Graphics", description: "Type and design systems built to move with intention, not decoration." },
  { id: "cgi", index: 9, title: "CGI", description: "Photoreal environments and objects that don't exist — until they're on screen." },
  { id: "social-campaigns", index: 10, title: "Social Campaigns", description: "Cut-down storytelling that still respects the craft of the full film." },
  { id: "storytelling", index: 11, title: "Storytelling", description: "Every service above, in service of one thing: a story worth watching." },
];
