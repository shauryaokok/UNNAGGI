import type { LoaderConfig } from "./types";

export const LOADER_CONFIG: LoaderConfig = {
  wordmark: "UNNAGGI",
  cyclingWords: ["IDEA", "FRAME", "LIGHT", "ACTION", "FILM"],
  minDurationMs: 2000,
};
