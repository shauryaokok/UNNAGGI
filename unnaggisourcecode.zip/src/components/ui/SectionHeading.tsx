interface SectionHeadingProps {
  eyebrow: string;
  title: string;
  description?: string;
  align?: "left" | "center";
}

export function SectionHeading({
  eyebrow,
  title,
  description,
  align = "left",
}: SectionHeadingProps) {
  return (
    <div
      data-reveal
      className={`flex flex-col gap-4 ${
        align === "center" ? "items-center text-center" : "items-start text-left"
      }`}
    >
      <span className="font-mono text-[11px] uppercase tracking-[0.4em] text-gold">
        {eyebrow}
      </span>
      <h2 className="max-w-3xl font-display text-4xl font-light leading-[1.05] text-ivory sm:text-6xl">
        {title}
      </h2>
      {description && (
        <p className="max-w-xl font-sans text-base text-ivory/70 sm:text-lg">
          {description}
        </p>
      )}
    </div>
  );
}
