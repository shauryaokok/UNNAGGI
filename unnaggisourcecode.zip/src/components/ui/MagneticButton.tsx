"use client";

import { motion, type HTMLMotionProps } from "motion/react";
import type { ReactNode } from "react";
import { useMagnetic } from "@/components/cursor/useMagnetic";
import { useCursor } from "@/components/cursor/CursorProvider";

interface MagneticButtonProps extends Omit<HTMLMotionProps<"button">, "ref"> {
  children: ReactNode;
  cursorLabel?: string;
  className?: string;
}

export function MagneticButton({
  children,
  cursorLabel = "View",
  className = "",
  ...props
}: MagneticButtonProps) {
  const { ref, x, y, onMouseMove, onMouseLeave } = useMagnetic<HTMLButtonElement>();
  const { setCursor, resetCursor } = useCursor();

  return (
    <motion.button
      ref={ref}
      style={{ x, y }}
      onMouseMove={onMouseMove}
      onMouseEnter={() => setCursor("hover", cursorLabel)}
      onMouseLeave={() => {
        onMouseLeave();
        resetCursor();
      }}
      className={className}
      {...props}
    >
      {children}
    </motion.button>
  );
}
