"use client";

import { useEffect, useRef, useState } from "react";

/** Pure-CSS bob animation, paused via IntersectionObserver whenever off-screen. */
export function ScrollCue({ label = "Scroll" }: { label?: string }) {
  const ref = useRef<HTMLDivElement>(null);
  const [visible, setVisible] = useState(true);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const observer = new IntersectionObserver(
      ([entry]) => setVisible(entry.isIntersecting),
      { threshold: 0.1 }
    );
    observer.observe(el);
    return () => observer.disconnect();
  }, []);

  return (
    <div
      ref={ref}
      className="flex flex-col items-center gap-3 font-mono text-[10px] uppercase tracking-[0.32em] text-ivory/70"
    >
      <span>{label}</span>
      <span
        data-paused={!visible}
        className="scroll-cue-line block h-10 w-px bg-gradient-to-b from-gold to-transparent"
      />
    </div>
  );
}
