import type { ReactNode } from "react";

interface MarqueeProps {
  children: ReactNode;
  durationSeconds?: number;
  className?: string;
}

/** Infinite horizontal scroller, pauses on hover, disabled under reduced motion. */
export function Marquee({ children, durationSeconds = 32, className = "" }: MarqueeProps) {
  return (
    <div className={`group relative overflow-hidden ${className}`}>
      <div
        className="marquee-track flex w-max items-center"
        style={{ animationDuration: `${durationSeconds}s` }}
      >
        <div className="flex items-center">{children}</div>
        <div className="flex items-center" aria-hidden="true">
          {children}
        </div>
      </div>
    </div>
  );
}
