"use client";

import { useState } from "react";
import { UnnaggiMark } from "@/components/brand/UnnaggiMark";
import { MagneticButton } from "@/components/ui/MagneticButton";

const NAV_LINKS = [
  { href: "#journey", label: "Journey" },
  { href: "#films", label: "Films" },
  { href: "#services", label: "Services" },
  { href: "#studio", label: "Studio" },
  { href: "#contact", label: "Contact" },
];

interface HeaderProps {
  visible: boolean;
}

/** Persistent brand mark + nav, fades in once the Loader hands off. */
export function Header({ visible }: HeaderProps) {
  const [open, setOpen] = useState(false);

  return (
    <>
      <header
        className={`fixed inset-x-0 top-0 z-40 flex items-center justify-between px-8 py-7 transition-opacity duration-700 sm:px-10 ${
          visible ? "opacity-100" : "pointer-events-none opacity-0"
        }`}
      >
        <a
          href="#top"
          onClick={() => setOpen(false)}
          className="flex items-center gap-3 text-ivory"
        >
          <UnnaggiMark className="h-6 w-auto text-ivory" />
          <span className="font-mono text-xs uppercase tracking-[0.32em]">
            Unnaggi
          </span>
        </a>

        <MagneticButton
          cursorLabel={open ? "Close" : "Menu"}
          onClick={() => setOpen((v) => !v)}
          className="font-mono text-xs uppercase tracking-[0.32em] text-ivory"
        >
          {open ? "Close" : "Menu"}
        </MagneticButton>
      </header>

      <div
        aria-hidden={!open}
        className={`fixed inset-0 z-30 flex items-center justify-center bg-navy/98 backdrop-blur-sm transition-opacity duration-500 ${
          open ? "pointer-events-auto opacity-100" : "pointer-events-none opacity-0"
        }`}
      >
        <nav className="flex flex-col items-center gap-7">
          {NAV_LINKS.map((link) => (
            <a
              key={link.href}
              href={link.href}
              onClick={() => setOpen(false)}
              className="font-display text-4xl font-light text-ivory transition-colors duration-300 hover:text-gold sm:text-6xl"
            >
              {link.label}
            </a>
          ))}
        </nav>
      </div>
    </>
  );
}
