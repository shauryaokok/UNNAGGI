"use client";

import { UnnaggiMark } from "@/components/brand/UnnaggiMark";
import { MagneticButton } from "@/components/ui/MagneticButton";
import { SITE } from "@/content/site";

const FOOTER_LINKS = [
  { href: "#journey", label: "Journey" },
  { href: "#films", label: "Films" },
  { href: "#services", label: "Services" },
  { href: "#studio", label: "Studio" },
  { href: "#contact", label: "Contact" },
];

const SOCIAL_LINKS = [
  { href: "https://instagram.com", label: "Instagram" },
  { href: "https://vimeo.com", label: "Vimeo" },
  { href: "https://linkedin.com", label: "LinkedIn" },
];

export function Footer() {
  const year = new Date().getFullYear();

  return (
    <footer className="relative border-t border-ivory/10 bg-navy px-8 py-16 sm:px-10">
      <div className="mx-auto flex max-w-6xl flex-col gap-16">
        <div className="flex flex-col items-start justify-between gap-10 sm:flex-row sm:items-end">
          <div className="flex flex-col gap-4">
            <UnnaggiMark className="h-8 w-auto text-ivory" />
            <p className="max-w-xs text-sm text-ivory/50">{SITE.tagline}</p>
          </div>

          <MagneticButton
            cursorLabel="Top"
            onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
            className="font-mono text-xs uppercase tracking-[0.3em] text-ivory/60 transition-colors hover:text-ivory"
          >
            Back To Top
          </MagneticButton>
        </div>

        <div className="flex flex-col gap-8 border-t border-ivory/10 pt-10 sm:flex-row sm:items-center sm:justify-between">
          <nav className="flex flex-wrap gap-x-8 gap-y-3">
            {FOOTER_LINKS.map((link) => (
              <a
                key={link.href}
                href={link.href}
                className="font-mono text-xs uppercase tracking-[0.25em] text-ivory/60 transition-colors hover:text-gold"
              >
                {link.label}
              </a>
            ))}
          </nav>

          <div className="flex gap-6">
            {SOCIAL_LINKS.map((social) => (
              <a
                key={social.label}
                href={social.href}
                target="_blank"
                rel="noreferrer"
                className="font-mono text-xs uppercase tracking-[0.25em] text-ivory/60 transition-colors hover:text-gold"
              >
                {social.label}
              </a>
            ))}
          </div>
        </div>

        <p className="font-mono text-[10px] uppercase tracking-[0.25em] text-ivory/30">
          © {year} {SITE.name}. All rights reserved.
        </p>
      </div>
    </footer>
  );
}
