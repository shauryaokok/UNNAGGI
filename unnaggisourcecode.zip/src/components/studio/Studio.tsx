"use client";

import { useRef } from "react";
import { useGSAP } from "@gsap/react";
import { gsap, ScrollTrigger } from "@/lib/gsap";
import { STUDIO_MANIFESTO, STUDIO_STATS } from "@/content/studio.content";
import { gsapEase } from "@/lib/motion-tokens";
import { SectionHeading } from "@/components/ui/SectionHeading";
import { useRevealOnScroll } from "@/hooks/useRevealOnScroll";

export function Studio() {
  const ref = useRevealOnScroll<HTMLElement>();
  const statRefs = useRef<(HTMLSpanElement | null)[]>([]);

  useGSAP(
    () => {
      STUDIO_STATS.forEach((stat, i) => {
        const el = statRefs.current[i];
        if (!el) return;
        const counter = { value: 0 };
        ScrollTrigger.create({
          trigger: el,
          start: "top 90%",
          once: true,
          onEnter: () => {
            gsap.to(counter, {
              value: stat.value,
              duration: 1.6,
              ease: gsapEase.reveal,
              onUpdate: () => {
                el.textContent = `${Math.round(counter.value)}${stat.suffix ?? ""}`;
              },
            });
          },
        });
      });
    },
    { scope: ref }
  );

  return (
    <section
      id="studio"
      ref={ref}
      className="relative bg-navy px-8 py-32 sm:px-10 lg:py-40"
    >
      <div className="mx-auto max-w-5xl">
        <SectionHeading
          eyebrow="The Studio"
          title="A small team built to move like a full house."
        />

        <p
          data-reveal
          className="mt-10 max-w-2xl font-display text-2xl font-light leading-relaxed text-ivory/85 sm:text-3xl"
        >
          {STUDIO_MANIFESTO}
        </p>

        <div className="mt-20 grid grid-cols-2 gap-10 border-t border-ivory/10 pt-12 sm:grid-cols-4">
          {STUDIO_STATS.map((stat, i) => (
            <div key={stat.id} data-reveal className="flex flex-col gap-2">
              <span
                ref={(el) => {
                  statRefs.current[i] = el;
                }}
                className="font-display text-4xl font-light text-gold sm:text-5xl"
              >
                0{stat.suffix ?? ""}
              </span>
              <span className="font-mono text-[10px] uppercase tracking-[0.25em] text-ivory/50">
                {stat.label}
              </span>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
