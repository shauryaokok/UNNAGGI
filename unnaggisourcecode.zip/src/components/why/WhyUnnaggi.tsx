"use client";

import { WHY_STATEMENTS } from "@/content/why.content";
import { SectionHeading } from "@/components/ui/SectionHeading";
import { useRevealOnScroll } from "@/hooks/useRevealOnScroll";

export function WhyUnnaggi() {
  const ref = useRevealOnScroll<HTMLElement>();

  return (
    <section
      ref={ref}
      className="relative bg-almost-black px-8 py-32 sm:px-10 lg:py-40"
    >
      <div className="mx-auto max-w-6xl">
        <SectionHeading eyebrow="Why UNNAGGI" title="The difference is in the discipline." />

        <div className="mt-20 grid gap-x-12 gap-y-16 sm:grid-cols-2">
          {WHY_STATEMENTS.map((item, i) => (
            <div
              key={item.id}
              data-reveal
              className={`flex flex-col gap-4 ${i % 2 === 1 ? "sm:mt-16" : ""}`}
            >
              <h3 className="font-display text-3xl font-light leading-tight text-ivory sm:text-4xl">
                {item.title}
              </h3>
              <p className="max-w-sm text-sm text-ivory/60 sm:text-base">
                {item.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
