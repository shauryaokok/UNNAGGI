interface UnnaggiMarkProps {
  className?: string;
}

/**
 * A clean vector recreation of the camera-icon mark, in `currentColor` so it can
 * be recolored per context. Swap for the real logo file once it's available on
 * disk (drop it in public/brand/ and replace this component's usage).
 */
export function UnnaggiMark({ className }: UnnaggiMarkProps) {
  return (
    <svg
      viewBox="0 0 120 90"
      fill="none"
      className={className}
      aria-hidden="true"
    >
      <circle cx="40" cy="18" r="14" stroke="currentColor" strokeWidth="4" />
      <circle cx="40" cy="18" r="5" fill="currentColor" />
      <circle cx="76" cy="16" r="10" stroke="currentColor" strokeWidth="3.5" />
      <circle cx="76" cy="16" r="3.5" fill="currentColor" />
      <rect x="14" y="38" width="70" height="38" rx="4" fill="currentColor" />
      <path d="M84 48 L104 38 L104 76 L84 66 Z" fill="currentColor" />
    </svg>
  );
}
