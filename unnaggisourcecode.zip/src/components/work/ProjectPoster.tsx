"use client";

import { motion } from "motion/react";
import type { Project } from "@/content/types";
import { moodTint } from "@/lib/motion-tokens";
import { hasRealSource } from "@/lib/media";
import { useCursor } from "@/components/cursor/CursorProvider";
import { CATEGORY_MOOD } from "./categoryMood";

interface ProjectPosterProps {
  project: Project;
  onOpen: (project: Project) => void;
}

export function ProjectPoster({ project, onOpen }: ProjectPosterProps) {
  const { setCursor, resetCursor } = useCursor();
  const mood = CATEGORY_MOOD[project.category];

  return (
    <motion.button
      type="button"
      data-reveal
      onClick={() => onOpen(project)}
      onMouseEnter={() => setCursor("view", "View")}
      onMouseLeave={resetCursor}
      whileHover={{ scale: 1.02 }}
      transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
      className="group relative flex aspect-[2/3] w-full flex-col justify-end overflow-hidden rounded-sm border border-ivory/10 text-left"
    >
      <div className="absolute inset-0 -z-10">
        {hasRealSource(project.media) ? (
          // eslint-disable-next-line @next/next/no-img-element -- arbitrary future CMS-provided src
          <img
            src={project.media?.src}
            alt={project.media?.alt ?? project.title}
            className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-110"
          />
        ) : (
          <div
            className="h-full w-full transition-transform duration-700 group-hover:scale-110"
            style={{
              background: `radial-gradient(120% 90% at 50% 20%, ${moodTint[mood]}, var(--color-almost-black) 80%)`,
            }}
          />
        )}
        <div className="absolute inset-0 bg-gradient-to-t from-almost-black via-almost-black/20 to-transparent opacity-80 transition-opacity duration-500 group-hover:opacity-95" />
        <div className="absolute inset-0 origin-top scale-y-0 bg-gradient-to-b from-gold/15 to-transparent transition-transform duration-700 group-hover:scale-y-100" />
      </div>

      <div className="relative flex flex-col gap-2 p-6">
        <span className="font-mono text-[10px] uppercase tracking-[0.3em] text-gold">
          {project.category} — {project.year}
        </span>
        <h3 className="font-display text-2xl font-light leading-tight text-ivory sm:text-3xl">
          {project.title}
        </h3>
        <span className="max-h-0 overflow-hidden font-sans text-xs text-ivory/70 opacity-0 transition-all duration-500 group-hover:max-h-12 group-hover:opacity-100">
          {project.client}
        </span>
      </div>
    </motion.button>
  );
}
