import type { ProjectCategory } from "@/content/types";
import type { moodTint } from "@/lib/motion-tokens";

export const CATEGORY_MOOD: Record<ProjectCategory, keyof typeof moodTint> = {
  Commercial: "neutral",
  "Luxury Brand": "warm",
  Automotive: "cool",
  Fashion: "warm",
  CGI: "flash",
};
