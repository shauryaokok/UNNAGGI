"use client";

import { useState } from "react";
import { PROJECTS } from "@/content/projects.content";
import type { Project } from "@/content/types";
import { SectionHeading } from "@/components/ui/SectionHeading";
import { useRevealOnScroll } from "@/hooks/useRevealOnScroll";
import { useCursor } from "@/components/cursor/CursorProvider";
import { ProjectPoster } from "./ProjectPoster";
import { ProjectDetailOverlay } from "./ProjectDetailOverlay";

export function FeaturedFilms() {
  const ref = useRevealOnScroll<HTMLElement>();
  const [selected, setSelected] = useState<Project | null>(null);
  const { resetCursor } = useCursor();

  return (
    <section
      id="films"
      ref={ref}
      className="relative bg-navy px-8 py-32 sm:px-10 lg:py-40"
    >
      <div className="mx-auto max-w-6xl">
        <SectionHeading
          eyebrow="Featured Films"
          title="Every project, its own poster."
          description="Six films, six different problems solved. Select one to open the case study."
        />

        <div className="mt-16 grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {PROJECTS.map((project) => (
            <ProjectPoster
              key={project.id}
              project={project}
              onOpen={(p) => {
                resetCursor();
                setSelected(p);
              }}
            />
          ))}
        </div>
      </div>

      <ProjectDetailOverlay
        project={selected}
        onClose={() => {
          resetCursor();
          setSelected(null);
        }}
      />
    </section>
  );
}
