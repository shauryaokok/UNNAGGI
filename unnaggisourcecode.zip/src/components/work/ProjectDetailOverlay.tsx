"use client";

import { useEffect } from "react";
import { AnimatePresence, motion } from "motion/react";
import type { Project } from "@/content/types";
import { moodTint, framerEase } from "@/lib/motion-tokens";
import { MagneticButton } from "@/components/ui/MagneticButton";
import { CATEGORY_MOOD } from "./categoryMood";

interface ProjectDetailOverlayProps {
  project: Project | null;
  onClose: () => void;
}

/** The "case study opens like a premium documentary" fullscreen transition. */
export function ProjectDetailOverlay({ project, onClose }: ProjectDetailOverlayProps) {
  useEffect(() => {
    if (!project) return;
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKey);
    document.body.classList.add("is-locked");
    return () => {
      window.removeEventListener("keydown", onKey);
      document.body.classList.remove("is-locked");
    };
  }, [project, onClose]);

  return (
    <AnimatePresence>
      {project && (
        <motion.div
          role="dialog"
          aria-modal="true"
          aria-label={project.title}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.4 }}
          className="fixed inset-0 z-[80] flex items-center justify-center overflow-y-auto bg-navy/97 px-6 py-16 backdrop-blur-md sm:px-10"
        >
          <motion.div
            initial={{ opacity: 0, y: 40, scale: 0.98 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.98 }}
            transition={{ duration: 0.5, ease: framerEase.cinematic }}
            className="relative flex w-full max-w-4xl flex-col gap-8"
          >
            <MagneticButton
              onClick={onClose}
              cursorLabel="Close"
              className="absolute -top-12 right-0 font-mono text-xs uppercase tracking-[0.3em] text-ivory/60 transition-colors hover:text-ivory"
            >
              Close
            </MagneticButton>

            <div
              aria-hidden="true"
              className="aspect-video w-full overflow-hidden rounded-sm border border-ivory/10"
              style={{
                background: `radial-gradient(120% 90% at 50% 20%, ${moodTint[CATEGORY_MOOD[project.category]]}, var(--color-almost-black) 80%)`,
              }}
            />

            <div className="flex flex-col gap-4">
              <span className="font-mono text-xs uppercase tracking-[0.3em] text-gold">
                {project.category} — {project.year}
              </span>
              <h2 className="font-display text-4xl font-light leading-tight text-ivory sm:text-5xl">
                {project.title}
              </h2>
              <p className="max-w-2xl text-base leading-relaxed text-ivory/70">
                {project.synopsis}
              </p>
              <span className="font-mono text-xs uppercase tracking-[0.2em] text-ivory/50">
                Client — {project.client}
              </span>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
