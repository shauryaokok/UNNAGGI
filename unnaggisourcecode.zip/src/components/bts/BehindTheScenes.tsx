"use client";

import { BTS_FRAMES } from "@/content/behindTheScenes.content";
import { moodTint } from "@/lib/motion-tokens";
import { hasRealSource } from "@/lib/media";
import { SectionHeading } from "@/components/ui/SectionHeading";
import { useRevealOnScroll } from "@/hooks/useRevealOnScroll";

export function BehindTheScenes() {
  const ref = useRevealOnScroll<HTMLElement>();

  return (
    <section
      ref={ref}
      className="relative bg-navy px-8 py-32 sm:px-10 lg:py-40"
    >
      <div className="mx-auto max-w-6xl">
        <SectionHeading
          eyebrow="Behind The Scenes"
          title="Don't tell. Show."
          description="The making of, not the highlight reel."
        />

        <div className="mt-16 grid grid-cols-2 gap-3 sm:auto-rows-[180px] sm:grid-cols-4">
          {BTS_FRAMES.map((frame, i) => (
            <div
              key={frame.id}
              data-reveal
              className={`group relative overflow-hidden rounded-sm border border-ivory/10 ${
                i % 5 === 0 ? "sm:col-span-2 sm:row-span-2" : ""
              }`}
            >
              {hasRealSource(frame.media) ? (
                // eslint-disable-next-line @next/next/no-img-element -- arbitrary future CMS-provided src
                <img
                  src={frame.media?.src}
                  alt={frame.media?.alt ?? frame.caption}
                  className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-110"
                />
              ) : (
                <div
                  className="h-full min-h-[140px] w-full transition-transform duration-700 group-hover:scale-110"
                  style={{
                    background: `radial-gradient(120% 100% at 50% 30%, ${moodTint[frame.mood]}, var(--color-almost-black) 80%)`,
                  }}
                />
              )}
              <div className="absolute inset-0 bg-gradient-to-t from-almost-black/90 via-transparent to-transparent" />
              <span className="absolute bottom-3 left-3 font-mono text-[10px] uppercase tracking-[0.25em] text-ivory/80">
                {frame.caption}
              </span>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
