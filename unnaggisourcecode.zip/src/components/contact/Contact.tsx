"use client";

import { CONTACT } from "@/content/contact.content";
import { MagneticButton } from "@/components/ui/MagneticButton";
import { useRevealOnScroll } from "@/hooks/useRevealOnScroll";

export function Contact() {
  const ref = useRevealOnScroll<HTMLElement>();

  return (
    <section
      id="contact"
      ref={ref}
      className="relative flex min-h-[70vh] flex-col items-center justify-center bg-almost-black px-8 py-32 text-center sm:px-10"
    >
      <span
        data-reveal
        className="font-mono text-[11px] uppercase tracking-[0.4em] text-gold"
      >
        Let&rsquo;s Talk
      </span>
      <h2
        data-reveal
        className="mt-8 max-w-3xl font-display text-4xl font-light leading-tight text-ivory sm:text-7xl"
      >
        {CONTACT.statement}
      </h2>
      <div data-reveal className="mt-12">
        <MagneticButton
          cursorLabel="Email"
          onClick={() => {
            window.location.href = `mailto:${CONTACT.email}`;
          }}
          className="border border-gold/60 px-10 py-5 font-mono text-xs uppercase tracking-[0.3em] text-ivory transition-colors duration-300 hover:bg-gold/10"
        >
          {CONTACT.ctaLabel}
        </MagneticButton>
      </div>
    </section>
  );
}
