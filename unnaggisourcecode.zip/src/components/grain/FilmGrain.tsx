/**
 * A single shared grain texture, rendered once as a fixed SVG filter — never redrawn
 * per frame. The subtle opacity pulse is a pure CSS keyframe (compositor-only, no JS),
 * and is disabled entirely under prefers-reduced-motion via globals.css.
 */
export function FilmGrain() {
  return (
    <div
      aria-hidden="true"
      className="film-grain pointer-events-none fixed inset-0 z-50 mix-blend-overlay"
    >
      <svg className="h-full w-full" preserveAspectRatio="none">
        <filter id="unnaggi-grain">
          <feTurbulence
            type="fractalNoise"
            baseFrequency="0.85"
            numOctaves="2"
            stitchTiles="stitch"
          />
          <feColorMatrix type="saturate" values="0" />
        </filter>
        <rect width="100%" height="100%" filter="url(#unnaggi-grain)" />
      </svg>
    </div>
  );
}
