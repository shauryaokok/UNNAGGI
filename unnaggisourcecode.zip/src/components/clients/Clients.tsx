"use client";

import { motion } from "motion/react";
import { CLIENTS } from "@/content/clients.content";
import { SectionHeading } from "@/components/ui/SectionHeading";
import { useRevealOnScroll } from "@/hooks/useRevealOnScroll";
import { useReducedMotion } from "@/hooks/useReducedMotion";

/** Deterministic pseudo-random, rounded to avoid cross-engine float drift on hydration. */
function seeded(seed: number) {
  const x = Math.sin(seed * 12.9898) * 43758.5453;
  return Math.round((x - Math.floor(x)) * 1000) / 1000;
}

export function Clients() {
  const ref = useRevealOnScroll<HTMLElement>();
  const reduced = useReducedMotion();

  return (
    <section
      ref={ref}
      className="relative overflow-hidden bg-almost-black px-8 py-32 sm:px-10 lg:py-40"
    >
      <div className="mx-auto max-w-6xl">
        <SectionHeading
          eyebrow="Trusted By"
          title="A growing ecosystem of ambitious brands."
          align="center"
        />

        <div className="relative mt-20 flex min-h-[420px] flex-wrap items-center justify-center gap-x-10 gap-y-8 sm:gap-x-14">
          {CLIENTS.map((client, i) => {
            const driftY = 6 + seeded(i + 1) * 10;
            const duration = 4 + seeded(i + 20) * 3;
            const delay = seeded(i + 50) * 2;
            return (
              <motion.span
                key={client.id}
                data-reveal
                animate={reduced ? undefined : { y: [0, -driftY, 0] }}
                transition={{
                  duration,
                  delay,
                  repeat: Infinity,
                  ease: "easeInOut",
                }}
                className="font-display text-xl font-light text-ivory/40 transition-colors duration-500 hover:text-gold sm:text-2xl"
              >
                {client.name}
              </motion.span>
            );
          })}
        </div>
      </div>
    </section>
  );
}
