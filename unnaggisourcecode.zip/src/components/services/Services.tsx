"use client";

import { useState } from "react";
import { SERVICES } from "@/content/services.content";
import { SectionHeading } from "@/components/ui/SectionHeading";
import { useRevealOnScroll } from "@/hooks/useRevealOnScroll";
import { useCursor } from "@/components/cursor/CursorProvider";

export function Services() {
  const ref = useRevealOnScroll<HTMLElement>();
  const [hovered, setHovered] = useState<string | null>(null);
  const { setCursor, resetCursor } = useCursor();

  return (
    <section
      id="services"
      ref={ref}
      className="relative bg-navy px-8 py-32 sm:px-10 lg:py-40"
    >
      <div className="mx-auto max-w-5xl">
        <SectionHeading eyebrow="Capabilities" title="What we make." />

        <ul className="mt-16 border-t border-ivory/10">
          {SERVICES.map((service) => {
            const isHovered = hovered === service.id;
            const isDimmed = hovered !== null && !isHovered;
            return (
              <li
                key={service.id}
                data-reveal
                onMouseEnter={() => {
                  setHovered(service.id);
                  setCursor("hover", "→");
                }}
                onMouseLeave={() => {
                  setHovered(null);
                  resetCursor();
                }}
                className={`group flex flex-col gap-2 border-b border-ivory/10 py-6 transition-opacity duration-500 sm:flex-row sm:items-baseline sm:justify-between sm:py-8 ${
                  isDimmed ? "opacity-40" : "opacity-100"
                }`}
              >
                <div className="flex items-baseline gap-6">
                  <span className="font-mono text-xs text-gold">
                    {String(service.index).padStart(2, "0")}
                  </span>
                  <h3 className="font-display text-2xl font-light text-ivory transition-transform duration-500 sm:text-4xl sm:group-hover:translate-x-3">
                    {service.title}
                  </h3>
                </div>
                <p
                  className={`max-w-sm text-sm text-ivory/60 opacity-100 transition-opacity duration-500 sm:text-right ${
                    isHovered ? "sm:opacity-100" : "sm:opacity-0"
                  }`}
                >
                  {service.description}
                </p>
              </li>
            );
          })}
        </ul>
      </div>
    </section>
  );
}
