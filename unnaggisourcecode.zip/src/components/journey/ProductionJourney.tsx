"use client";

import { JOURNEY_STAGES } from "@/content/journey.content";
import { SectionHeading } from "@/components/ui/SectionHeading";
import { useRevealOnScroll } from "@/hooks/useRevealOnScroll";

export function ProductionJourney() {
  const ref = useRevealOnScroll<HTMLElement>();

  return (
    <section
      id="journey"
      ref={ref}
      className="relative bg-navy px-8 py-32 sm:px-10 lg:py-40"
    >
      <div className="mx-auto max-w-6xl">
        <SectionHeading
          eyebrow="How We Work"
          title="Every production, one continuous line."
          description="Not a pitch deck of services — the actual path a film takes from a first conversation to final delivery."
        />

        <div className="relative mt-20 grid gap-16 sm:grid-cols-2 lg:grid-cols-4">
          <div className="pointer-events-none absolute inset-x-0 top-8 hidden h-px bg-gradient-to-r from-transparent via-ivory/15 to-transparent lg:block" />
          {JOURNEY_STAGES.map((stage) => (
            <div key={stage.id} data-reveal className="relative flex flex-col gap-5">
              <span
                aria-hidden="true"
                className="pointer-events-none absolute -top-6 -left-2 select-none font-display text-8xl font-light text-ivory/[0.04]"
              >
                0{stage.index}
              </span>
              <span className="relative font-mono text-xs tracking-[0.3em] text-gold">
                0{stage.index}
              </span>
              <h3 className="relative font-display text-2xl font-light text-ivory sm:text-3xl">
                {stage.title}
              </h3>
              <p className="relative text-sm leading-relaxed text-ivory/65 sm:text-base">
                {stage.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
