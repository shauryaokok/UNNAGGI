"use client";

import { useRef, type MouseEvent, type RefObject } from "react";
import { useMotionValue, useSpring } from "motion/react";

interface MagneticHandlers<T extends HTMLElement> {
  ref: RefObject<T | null>;
  x: ReturnType<typeof useSpring>;
  y: ReturnType<typeof useSpring>;
  onMouseMove: (event: MouseEvent<T>) => void;
  onMouseLeave: () => void;
}

/** Pulls an element toward the cursor within its own bounds, springs back on leave. */
export function useMagnetic<T extends HTMLElement = HTMLElement>(
  strength = 0.35
): MagneticHandlers<T> {
  const ref = useRef<T>(null);
  const x = useMotionValue(0);
  const y = useMotionValue(0);
  const springX = useSpring(x, { stiffness: 220, damping: 16, mass: 0.3 });
  const springY = useSpring(y, { stiffness: 220, damping: 16, mass: 0.3 });

  const onMouseMove = (event: MouseEvent<T>) => {
    const el = ref.current;
    if (!el) return;
    const rect = el.getBoundingClientRect();
    const relativeX = event.clientX - (rect.left + rect.width / 2);
    const relativeY = event.clientY - (rect.top + rect.height / 2);
    x.set(relativeX * strength);
    y.set(relativeY * strength);
  };

  const onMouseLeave = () => {
    x.set(0);
    y.set(0);
  };

  return { ref, x: springX, y: springY, onMouseMove, onMouseLeave };
}
