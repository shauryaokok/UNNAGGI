"use client";

import { useEffect, useState } from "react";
import { motion, useMotionValue, useSpring } from "motion/react";
import { useCursor } from "./CursorProvider";
import { isTouchDevice, prefersReducedMotion } from "@/lib/device";

/**
 * Decorative only (aria-hidden) — the native cursor is never removed from the DOM's
 * accessibility tree, so keyboard/AT users lose nothing.
 */
export function CustomCursor() {
  const { variant, label } = useCursor();
  const [enabled, setEnabled] = useState(false);

  const x = useMotionValue(-100);
  const y = useMotionValue(-100);
  const springX = useSpring(x, { stiffness: 500, damping: 42, mass: 0.4 });
  const springY = useSpring(y, { stiffness: 500, damping: 42, mass: 0.4 });

  useEffect(() => {
    if (isTouchDevice() || prefersReducedMotion()) return;
    setEnabled(true);
    document.body.style.cursor = "none";

    const handleMove = (event: MouseEvent) => {
      x.set(event.clientX);
      y.set(event.clientY);
    };
    window.addEventListener("mousemove", handleMove);
    return () => {
      window.removeEventListener("mousemove", handleMove);
      document.body.style.cursor = "";
    };
  }, [x, y]);

  if (!enabled) return null;

  const isExpanded = variant === "hover" || variant === "view";
  const isHidden = variant === "hidden";

  return (
    <motion.div
      aria-hidden="true"
      className="pointer-events-none fixed left-0 top-0 z-[100] mix-blend-difference"
      style={{ x: springX, y: springY, translateX: "-50%", translateY: "-50%" }}
    >
      <motion.div
        animate={{
          width: isExpanded ? 96 : 14,
          height: isExpanded ? 96 : 14,
          opacity: isHidden ? 0 : 1,
        }}
        transition={{ type: "spring", stiffness: 320, damping: 30 }}
        className="flex items-center justify-center rounded-full border border-ivory bg-ivory/10"
      >
        {label && (
          <span className="whitespace-nowrap font-mono text-[10px] uppercase tracking-[0.24em] text-ivory">
            {label}
          </span>
        )}
      </motion.div>
    </motion.div>
  );
}
