"use client";

import {
  createContext,
  useCallback,
  useContext,
  useState,
  type ReactNode,
} from "react";

export type CursorVariant = "default" | "hover" | "view" | "hidden";

interface CursorContextValue {
  variant: CursorVariant;
  label: string | null;
  setCursor: (variant: CursorVariant, label?: string | null) => void;
  resetCursor: () => void;
}

const CursorContext = createContext<CursorContextValue | null>(null);

export function useCursor() {
  const ctx = useContext(CursorContext);
  if (!ctx) {
    throw new Error("useCursor must be used within a CursorProvider");
  }
  return ctx;
}

export function CursorProvider({ children }: { children: ReactNode }) {
  const [variant, setVariant] = useState<CursorVariant>("default");
  const [label, setLabel] = useState<string | null>(null);

  const setCursor = useCallback(
    (nextVariant: CursorVariant, nextLabel: string | null = null) => {
      setVariant(nextVariant);
      setLabel(nextLabel);
    },
    []
  );

  const resetCursor = useCallback(() => {
    setVariant("default");
    setLabel(null);
  }, []);

  return (
    <CursorContext.Provider value={{ variant, label, setCursor, resetCursor }}>
      {children}
    </CursorContext.Provider>
  );
}
