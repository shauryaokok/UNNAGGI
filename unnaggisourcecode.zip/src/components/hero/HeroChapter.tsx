import { forwardRef } from "react";
import type { HeroChapterContent } from "@/content/types";
import { HERO_CHAPTER_COUNT } from "@/lib/motion-tokens";
import { VideoLayer } from "./layers/VideoLayer";
import { LightingLayer } from "./layers/LightingLayer";
import { MotionLayer } from "./layers/MotionLayer";
import { NoiseLayer } from "./layers/NoiseLayer";
import { TypographyLayer } from "./layers/TypographyLayer";
import { OverlayLayer } from "./layers/OverlayLayer";
import { InteractionLayer } from "./layers/InteractionLayer";

interface HeroChapterProps {
  chapter: HeroChapterContent;
  /** Reduced-motion mode skips the scrub engine entirely, so content must render fully visible. */
  reducedMotion?: boolean;
}

/** Composes the seven-layer stack for one chapter. Visibility/motion is driven imperatively by Hero.tsx. */
export const HeroChapter = forwardRef<HTMLDivElement, HeroChapterProps>(
  function HeroChapter({ chapter, reducedMotion }, ref) {
    return (
      <div
        ref={ref}
        data-chapter-id={chapter.id}
        className={reducedMotion ? "absolute inset-0 opacity-100" : "absolute inset-0 opacity-0"}
      >
        <VideoLayer media={chapter.media} mood={chapter.mood} />
        <LightingLayer mood={chapter.mood} />
        <MotionLayer>
          <OverlayLayer chapterId={chapter.id} />
        </MotionLayer>
        <NoiseLayer />
        <TypographyLayer
          headline={chapter.headline}
          microcopy={chapter.microcopy}
          index={chapter.index}
          total={HERO_CHAPTER_COUNT}
        />
        <InteractionLayer />
      </div>
    );
  }
);
