import type { ReactNode } from "react";

/** Cursor hit-targets / CTA — populated only by the closing statement in this reel. */
export function InteractionLayer({ children }: { children?: ReactNode }) {
  if (!children) return null;
  return <div className="absolute inset-0">{children}</div>;
}
