/**
 * A per-chapter vignette — works alongside the site-wide FilmGrain SVG texture
 * (mounted once in the layout) rather than duplicating that filter 11 times.
 */
export function NoiseLayer() {
  return (
    <div
      aria-hidden="true"
      className="absolute inset-0"
      style={{
        background:
          "radial-gradient(120% 90% at 50% 50%, transparent 45%, rgba(5,4,9,0.55) 100%)",
      }}
    />
  );
}
