import type { ChapterMood, MediaRef } from "@/content/types";
import { hasRealSource } from "@/lib/media";
import { GenerativeBase } from "./GenerativeBase";

interface VideoLayerProps {
  media?: MediaRef;
  mood: ChapterMood;
}

/**
 * Renders real footage the moment `content/hero.content.ts` provides a `src` —
 * until then, every chapter falls back to its generative base texture.
 */
export function VideoLayer({ media, mood }: VideoLayerProps) {
  if (hasRealSource(media)) {
    return (
      <div className="absolute inset-0 overflow-hidden">
        {media.kind === "video" ? (
          <video
            className="h-full w-full object-cover"
            src={media.src}
            poster={media.poster}
            autoPlay
            muted
            loop
            playsInline
            aria-hidden="true"
          />
        ) : (
          // eslint-disable-next-line @next/next/no-img-element -- arbitrary future CMS-provided src, next/image would require pre-registering every remote host
          <img
            src={media.src}
            alt={media.alt}
            className="h-full w-full object-cover"
          />
        )}
      </div>
    );
  }

  return <GenerativeBase mood={mood} />;
}
