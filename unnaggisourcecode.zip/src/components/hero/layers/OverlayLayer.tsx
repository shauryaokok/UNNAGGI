import type { ComponentType } from "react";
import type { ChapterId } from "@/content/types";
import { IdeaOverlay } from "../overlays/IdeaOverlay";
import { ScriptOverlay } from "../overlays/ScriptOverlay";
import { StoryboardOverlay } from "../overlays/StoryboardOverlay";
import { PreProductionOverlay } from "../overlays/PreProductionOverlay";
import { LightsOverlay } from "../overlays/LightsOverlay";
import { CameraOverlay } from "../overlays/CameraOverlay";
import { ActionOverlay } from "../overlays/ActionOverlay";
import { EditOverlay } from "../overlays/EditOverlay";
import { ColorGradingOverlay } from "../overlays/ColorGradingOverlay";
import { MotionGraphicsOverlay } from "../overlays/MotionGraphicsOverlay";
import { FinalFilmOverlay } from "../overlays/FinalFilmOverlay";

const OVERLAY_REGISTRY: Record<ChapterId, ComponentType> = {
  idea: IdeaOverlay,
  script: ScriptOverlay,
  storyboard: StoryboardOverlay,
  "pre-production": PreProductionOverlay,
  lights: LightsOverlay,
  camera: CameraOverlay,
  action: ActionOverlay,
  edit: EditOverlay,
  "color-grading": ColorGradingOverlay,
  "motion-graphics": MotionGraphicsOverlay,
  "final-film": FinalFilmOverlay,
};

/** Resolves a chapter's bespoke Overlay Layer treatment via a small id-keyed registry. */
export function OverlayLayer({ chapterId }: { chapterId: ChapterId }) {
  const Overlay = OVERLAY_REGISTRY[chapterId];
  return (
    <div className="absolute inset-0 flex items-center justify-center">
      <Overlay />
    </div>
  );
}
