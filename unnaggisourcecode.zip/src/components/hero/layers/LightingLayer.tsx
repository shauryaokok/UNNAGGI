import type { ChapterMood } from "@/content/types";

const MOOD_GRADIENTS: Record<ChapterMood, string> = {
  cool: "radial-gradient(120% 100% at 50% 20%, rgba(72,84,150,0.26), transparent 60%), linear-gradient(180deg, rgba(11,10,24,0.15), rgba(5,4,9,0.82))",
  warm: "radial-gradient(120% 100% at 50% 30%, rgba(216,178,110,0.22), transparent 62%), linear-gradient(180deg, rgba(11,10,24,0.1), rgba(5,4,9,0.82))",
  flash: "radial-gradient(140% 120% at 50% 50%, rgba(245,242,235,0.16), transparent 65%), linear-gradient(180deg, rgba(11,10,24,0.2), rgba(5,4,9,0.82))",
  neutral: "linear-gradient(180deg, rgba(11,10,24,0.2), rgba(5,4,9,0.82))",
};

/** The practical-light "mood" wash — what makes each chapter feel like a different set. */
export function LightingLayer({ mood }: { mood: ChapterMood }) {
  return (
    <div
      aria-hidden="true"
      className="absolute inset-0"
      style={{ background: MOOD_GRADIENTS[mood] }}
    />
  );
}
