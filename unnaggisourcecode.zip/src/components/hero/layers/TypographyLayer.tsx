interface TypographyLayerProps {
  headline: string;
  microcopy: string;
  index: number;
  total: number;
}

/**
 * Real accessible heading underneath (faint), decorative mask-fill duplicate on top —
 * the same wipe-reveal technique as the Loader wordmark, driven imperatively by
 * the chapter's scroll-scrub frame via the `data-role` hooks below.
 */
export function TypographyLayer({
  headline,
  microcopy,
  index,
  total,
}: TypographyLayerProps) {
  return (
    <div className="pointer-events-none absolute inset-0 flex flex-col items-center justify-center gap-6 px-6 text-center">
      <span className="font-mono text-[11px] uppercase tracking-[0.4em] text-gold">
        Ch. {String(index).padStart(2, "0")} / {String(total).padStart(2, "0")}
      </span>

      <div className="relative">
        <h2 className="select-none font-display text-[15vw] font-light leading-[0.95] text-ivory/10 sm:text-[9vw]">
          {headline}
        </h2>
        <span
          data-role="headline-fill"
          aria-hidden="true"
          className="absolute inset-0 select-none font-display text-[15vw] font-light leading-[0.95] text-ivory sm:text-[9vw]"
        >
          {headline}
        </span>
      </div>

      <p
        data-role="microcopy"
        className="max-w-md font-sans text-sm text-ivory/70 sm:text-base"
      >
        {microcopy}
      </p>
    </div>
  );
}
