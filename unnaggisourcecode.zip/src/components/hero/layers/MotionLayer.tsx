"use client";

import { motion } from "motion/react";
import type { ReactNode } from "react";
import { useHeroTilt } from "../HeroTiltContext";

/** The "camera movement" layer — wraps the Overlay art in a shared cursor-follow tilt. */
export function MotionLayer({ children }: { children: ReactNode }) {
  const { rotateX, rotateY } = useHeroTilt();

  return (
    <motion.div
      style={{ rotateX, rotateY, transformPerspective: 1200 }}
      className="absolute inset-0 will-change-transform"
    >
      {children}
    </motion.div>
  );
}
