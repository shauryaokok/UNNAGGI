import type { ChapterMood } from "@/content/types";
import { moodTint } from "@/lib/motion-tokens";

/** The Video Layer's generative fallback when no real footage is provided. */
export function GenerativeBase({ mood }: { mood: ChapterMood }) {
  return (
    <div
      aria-hidden="true"
      className="absolute inset-0"
      style={{
        background: `radial-gradient(140% 120% at 50% 40%, ${moodTint[mood]}, var(--color-almost-black) 75%)`,
      }}
    />
  );
}
