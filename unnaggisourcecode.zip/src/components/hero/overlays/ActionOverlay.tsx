export function ActionOverlay() {
  const streaks = Array.from({ length: 5 });
  return (
    <div className="relative h-full w-full overflow-hidden">
      {streaks.map((_, i) => (
        <span
          key={i}
          aria-hidden="true"
          className="absolute h-px bg-ivory/30"
          style={{
            width: "60vw",
            top: `${28 + i * 10}%`,
            left: "10%",
            transformOrigin: "left center",
            transform:
              "scaleX(var(--chapter-progress, 0)) translateX(calc((1 - var(--chapter-progress, 0)) * -12vw))",
          }}
        />
      ))}
    </div>
  );
}
