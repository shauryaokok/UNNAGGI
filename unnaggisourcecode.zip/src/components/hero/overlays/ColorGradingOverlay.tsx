export function ColorGradingOverlay() {
  return (
    <div className="relative h-[40vmin] w-[70vmin] overflow-hidden rounded-sm border border-ivory/15">
      <div
        aria-hidden="true"
        className="absolute inset-0"
        style={{
          background: "linear-gradient(135deg, #1B2340, #3A2A18)",
          filter: "saturate(0.4) brightness(0.8)",
        }}
      />
      <div
        aria-hidden="true"
        className="absolute inset-y-0 left-0 overflow-hidden"
        style={{ width: "calc(var(--chapter-progress, 0) * 100%)" }}
      >
        <div
          className="h-full w-[70vmin]"
          style={{
            background: "linear-gradient(135deg, #D8B26E, #5C4A2E)",
            filter: "saturate(1.2)",
          }}
        />
      </div>
      <div
        aria-hidden="true"
        className="absolute inset-y-0 w-px bg-ivory/60"
        style={{ left: "calc(var(--chapter-progress, 0) * 100%)" }}
      />
    </div>
  );
}
