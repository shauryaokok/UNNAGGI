"use client";

import { lazy, Suspense, useEffect, useState } from "react";
import { canUseAperture3D } from "@/lib/device";
import { useProgress } from "@/components/hero/progressStore";
import { HERO_CHAPTERS } from "@/content/hero.content";

const ApertureScene = lazy(() =>
  import("../aperture/ApertureScene").then((mod) => ({ default: mod.ApertureScene }))
);

const CAMERA_INDEX = HERO_CHAPTERS.findIndex((chapter) => chapter.id === "camera");

/**
 * SVG aperture blades always render (SSR-safe, works everywhere). The optional
 * R3F iris mounts on top only once a capable desktop is confirmed client-side
 * AND the reel is actually near this chapter — and unmounts again once it
 * scrolls past, so the GPU cost never lingers past the one moment it's worth it.
 */
export function CameraOverlay() {
  const [capable, setCapable] = useState(false);
  const activeIndex = useProgress("hero:active");
  const isNear = Math.abs(activeIndex - CAMERA_INDEX) <= 1;

  useEffect(() => {
    if (canUseAperture3D()) setCapable(true);
  }, []);

  const use3D = capable && isNear;
  const blades = Array.from({ length: 6 });

  return (
    <div className="relative flex h-[50vmin] w-[50vmin] items-center justify-center">
      <div className={use3D ? "invisible" : "contents"} aria-hidden="true">
        <div className="absolute inset-0 rounded-full border border-ivory/20" />
        {blades.map((_, i) => (
          <div
            key={i}
            className="absolute top-0 h-1/2 w-[18%] origin-bottom bg-gradient-to-t from-almost-black to-transparent"
            style={{
              left: "50%",
              transform: `translateX(-50%) rotate(${i * 60}deg) scaleY(calc(0.95 - var(--chapter-progress, 0) * 0.6))`,
            }}
          />
        ))}
        <div className="h-1/4 w-1/4 rounded-full bg-gold/20" />
      </div>

      {use3D && (
        <Suspense fallback={null}>
          <div className="absolute inset-0">
            <ApertureScene />
          </div>
        </Suspense>
      )}
    </div>
  );
}
