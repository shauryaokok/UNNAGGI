export function StoryboardOverlay() {
  return (
    <div className="flex h-full w-full items-center justify-center gap-4">
      {[0, 1, 2].map((i) => (
        <svg
          key={i}
          data-reveal
          data-reveal-at={0.1 + i * 0.15}
          data-reveal-duration={0.25}
          data-reveal-y={20}
          width="120"
          height="80"
          viewBox="0 0 120 80"
          className="opacity-90"
        >
          <rect
            x="2"
            y="2"
            width="116"
            height="76"
            fill="none"
            stroke="rgba(245,242,235,0.5)"
            strokeWidth="1.5"
            strokeDasharray="384"
            style={{
              strokeDashoffset: "calc(384 - var(--chapter-progress, 0) * 384)",
            }}
          />
          <line
            x1="20"
            y1="55"
            x2="60"
            y2="30"
            stroke="rgba(245,242,235,0.35)"
            strokeWidth="1"
          />
          <circle
            cx="82"
            cy="35"
            r="10"
            stroke="rgba(245,242,235,0.35)"
            strokeWidth="1"
            fill="none"
          />
        </svg>
      ))}
    </div>
  );
}
