export function FinalFilmOverlay() {
  const stripes = Array.from({ length: 6 });
  return (
    <div className="relative h-[30vmin] w-[46vmin]">
      <div className="absolute inset-x-0 bottom-0 top-[22%] rounded-sm border border-ivory/30 bg-almost-black/60" />
      <div
        aria-hidden="true"
        className="absolute inset-x-0 top-0 h-[22%] origin-left overflow-hidden bg-ivory/90"
        style={{
          transform: "rotate(calc((1 - var(--chapter-progress, 0)) * -16deg))",
        }}
      >
        {stripes.map((_, i) => (
          <div
            key={i}
            className="absolute top-0 h-full w-[10%] bg-navy"
            style={{ left: `${i * 18 - 5}%`, transform: "skewX(-20deg)" }}
          />
        ))}
      </div>
    </div>
  );
}
