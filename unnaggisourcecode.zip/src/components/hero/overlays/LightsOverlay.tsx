export function LightsOverlay() {
  return (
    <div
      aria-hidden="true"
      className="h-[70vmin] w-[70vmin] rounded-full"
      style={{
        background:
          "conic-gradient(from calc(var(--chapter-progress, 0) * 360deg), transparent 0deg, rgba(216,178,110,0.5) 30deg, transparent 90deg, transparent 360deg)",
        filter: "blur(20px)",
      }}
    />
  );
}
