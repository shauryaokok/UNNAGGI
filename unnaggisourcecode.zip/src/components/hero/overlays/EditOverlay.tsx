export function EditOverlay() {
  const frames = Array.from({ length: 8 });
  return (
    <div className="relative w-[min(85vw,560px)]">
      <div className="flex gap-1 overflow-hidden rounded-sm border border-ivory/15 bg-almost-black/50 p-2">
        {frames.map((_, i) => (
          <div
            key={i}
            data-reveal
            data-reveal-at={0.06 + i * 0.06}
            data-reveal-duration={0.15}
            className="h-10 flex-1 rounded-[2px] bg-ivory/10"
          />
        ))}
      </div>
      <div
        aria-hidden="true"
        className="absolute -top-2 -bottom-2 w-px bg-gold"
        style={{ left: "calc(var(--chapter-progress, 0) * 100%)" }}
      />
    </div>
  );
}
