const SWATCHES = ["#D8B26E", "#3A3A42", "#8B8B94", "#1B2340", "#5C4A2E", "#232232"];

export function PreProductionOverlay() {
  return (
    <div className="grid grid-cols-3 gap-3">
      {SWATCHES.map((color, i) => (
        <div
          key={color}
          data-reveal
          data-reveal-at={0.08 + i * 0.08}
          data-reveal-duration={0.2}
          data-reveal-scale={0.6}
          data-reveal-rotate={i % 2 === 0 ? -6 : 6}
          className="h-16 w-16 rounded-sm border border-ivory/15 sm:h-20 sm:w-20"
          style={{ background: color }}
        />
      ))}
    </div>
  );
}
