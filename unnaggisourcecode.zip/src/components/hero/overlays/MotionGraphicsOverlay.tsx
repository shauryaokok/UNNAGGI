const SHAPES = [
  { d: "M0 40 L40 0 L80 40 L40 80 Z", x: -60, y: -40 },
  { d: "M20 20 H60 V60 H20 Z", x: 60, y: -30 },
  { d: "M40 0 A40 40 0 1 1 39 0 Z", x: 0, y: 60 },
];

export function MotionGraphicsOverlay() {
  return (
    <svg viewBox="-100 -100 200 200" className="h-[45vmin] w-[45vmin]">
      {SHAPES.map((shape, i) => (
        <path
          key={i}
          d={shape.d}
          data-reveal
          data-reveal-at={0.1 + i * 0.15}
          data-reveal-duration={0.3}
          data-reveal-x={shape.x}
          data-reveal-y={shape.y}
          data-reveal-scale={0.4}
          fill="none"
          stroke="var(--color-gold)"
          strokeWidth="1.5"
          transform="translate(-40,-40)"
        />
      ))}
    </svg>
  );
}
