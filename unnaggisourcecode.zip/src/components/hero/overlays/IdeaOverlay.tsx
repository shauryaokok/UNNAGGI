export function IdeaOverlay() {
  const dots = Array.from({ length: 6 });
  return (
    <div className="relative flex h-full w-full items-center justify-center">
      <div
        aria-hidden="true"
        className="idea-pulse h-40 w-40 rounded-full"
        style={{
          background:
            "radial-gradient(circle, rgba(216,178,110,0.85), transparent 70%)",
          filter: "blur(2px)",
          transform: "scale(calc(0.7 + var(--chapter-progress, 0) * 0.5))",
        }}
      />
      {dots.map((_, i) => {
        const angle = (i / dots.length) * Math.PI * 2;
        return (
          <span
            key={i}
            data-reveal
            data-reveal-at={0.25 + i * 0.05}
            data-reveal-duration={0.2}
            data-reveal-y={24}
            className="absolute h-1 w-1 rounded-full bg-gold"
            style={{
              left: `${50 + Math.cos(angle) * 22}%`,
              top: `${50 + Math.sin(angle) * 22}%`,
            }}
          />
        );
      })}
    </div>
  );
}
