const LINES = [
  "FADE IN:",
  "INT. STUDIO — NIGHT",
  "A single light finds the frame.",
  "The story begins to speak.",
];

export function ScriptOverlay() {
  return (
    <div className="flex h-full w-full items-center justify-center">
      <div className="w-[min(80vw,420px)] rounded-sm border border-ivory/10 bg-almost-black/40 p-8 font-mono text-xs leading-7 text-ivory/70 backdrop-blur-sm">
        {LINES.map((line, i) => (
          <p
            key={line}
            data-reveal
            data-reveal-at={0.15 + i * 0.12}
            data-reveal-duration={0.18}
            data-reveal-x={-16}
          >
            {line}
          </p>
        ))}
        <span
          aria-hidden="true"
          className="script-cursor mt-1 inline-block h-3 w-1.5 bg-gold align-middle"
        />
      </div>
    </div>
  );
}
