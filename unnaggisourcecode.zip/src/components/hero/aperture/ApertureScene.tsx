"use client";

import { Canvas } from "@react-three/fiber";
import { ApertureBlades } from "./ApertureBlades";

/**
 * The one deliberate R3F moment in the reel — a genuine 3D iris for the Camera
 * chapter. Lazy-loaded and gated by `canUseAperture3D()`; the SVG blades in
 * CameraOverlay stand in whenever this can't (or shouldn't) mount.
 */
export function ApertureScene() {
  return (
    <Canvas
      camera={{ position: [0, 0, 5], fov: 35 }}
      gl={{ antialias: true, alpha: true, powerPreference: "low-power" }}
      dpr={[1, 1.5]}
    >
      <ambientLight intensity={0.5} />
      <pointLight position={[3, 3, 5]} intensity={40} color="#d8b26e" />
      <ApertureBlades />
    </Canvas>
  );
}
