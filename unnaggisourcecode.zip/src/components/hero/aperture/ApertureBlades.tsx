"use client";

import { useMemo } from "react";
import * as THREE from "three";
import { useProgress } from "@/components/hero/progressStore";

const BLADE_COUNT = 8;

/** A physically-approximate iris: N triangular blades that fan open with scroll progress. */
export function ApertureBlades() {
  const progress = useProgress("hero:camera");

  const shape = useMemo(() => {
    const s = new THREE.Shape();
    s.moveTo(0, -0.05);
    s.lineTo(1.3, -0.55);
    s.lineTo(1.3, 0.55);
    s.closePath();
    return s;
  }, []);

  const geometry = useMemo(() => new THREE.ShapeGeometry(shape), [shape]);

  const openAngle = 0.15 + progress * 0.55;

  return (
    <group rotation={[0, 0, progress * 0.4]}>
      {Array.from({ length: BLADE_COUNT }).map((_, i) => {
        const baseAngle = (i / BLADE_COUNT) * Math.PI * 2;
        return (
          <mesh key={i} geometry={geometry} rotation={[0, 0, baseAngle + openAngle]}>
            <meshStandardMaterial
              color="#0b0a18"
              metalness={0.3}
              roughness={0.6}
              side={THREE.DoubleSide}
            />
          </mesh>
        );
      })}
      <mesh>
        <ringGeometry args={[1.28, 1.35, 64]} />
        <meshBasicMaterial color="#d8b26e" transparent opacity={0.6} side={THREE.DoubleSide} />
      </mesh>
    </group>
  );
}
