"use client";

import { useEffect, useRef, useState } from "react";
import { useGSAP } from "@gsap/react";
import { ScrollTrigger } from "@/lib/gsap";
import { HERO_CHAPTERS } from "@/content/hero.content";
import { HERO_CHAPTER_COUNT } from "@/lib/motion-tokens";
import { useReducedMotion } from "@/hooks/useReducedMotion";
import { HeroChapter } from "./HeroChapter";
import { HeroFinalStatement } from "./HeroFinalStatement";
import { HeroProgressRail } from "./HeroProgressRail";
import { HeroTiltProvider } from "./HeroTiltContext";
import { setProgress } from "./progressStore";
import {
  applyChapterFrame,
  collectChapterNodes,
  resetChapterFrame,
  type ChapterNodes,
} from "./chapterFrame";

const TOTAL_UNITS = HERO_CHAPTER_COUNT + 1;
const CAMERA_INDEX = HERO_CHAPTERS.findIndex((chapter) => chapter.id === "camera");

export function Hero() {
  const wrapperRef = useRef<HTMLDivElement>(null);
  const chapterRefs = useRef<(HTMLDivElement | null)[]>([]);
  const closingRef = useRef<HTMLDivElement>(null);
  const reducedMotion = useReducedMotion();
  const [heroInView, setHeroInView] = useState(true);

  useEffect(() => {
    const el = wrapperRef.current;
    if (!el) return;
    const observer = new IntersectionObserver(
      ([entry]) => setHeroInView(entry.isIntersecting),
      { threshold: 0 }
    );
    observer.observe(el);
    return () => observer.disconnect();
  }, []);

  useGSAP(
    () => {
      if (reducedMotion || !wrapperRef.current) return;

      const chapterNodes: ChapterNodes[] = [];
      chapterRefs.current.forEach((el) => {
        if (el) chapterNodes.push(collectChapterNodes(el));
      });
      const closingNodes = closingRef.current
        ? collectChapterNodes(closingRef.current)
        : null;

      chapterNodes.forEach(resetChapterFrame);
      if (closingNodes) resetChapterFrame(closingNodes);

      const trigger = ScrollTrigger.create({
        trigger: wrapperRef.current,
        start: "top top",
        end: "bottom bottom",
        scrub: 0.6,
        onUpdate: (self) => {
          const scaled = self.progress * TOTAL_UNITS;
          const activeIndex = Math.min(TOTAL_UNITS - 1, Math.floor(scaled));
          setProgress("hero:active", activeIndex);
          setProgress("hero:overall", self.progress);

          chapterNodes.forEach((nodes, i) => {
            applyChapterFrame(nodes, scaled - i);
          });
          if (closingNodes) {
            applyChapterFrame(closingNodes, scaled - HERO_CHAPTER_COUNT);
          }
          if (CAMERA_INDEX >= 0) {
            setProgress(
              "hero:camera",
              Math.min(1, Math.max(0, scaled - CAMERA_INDEX))
            );
          }
        },
      });

      return () => trigger.kill();
    },
    { scope: wrapperRef, dependencies: [reducedMotion] }
  );

  if (reducedMotion) {
    return (
      <HeroTiltProvider>
        <section id="top" aria-label="The UNNAGGI production journey" className="relative bg-navy">
          {HERO_CHAPTERS.map((chapter) => (
            <div
              key={chapter.id}
              className="relative flex min-h-screen items-center justify-center overflow-hidden"
            >
              <HeroChapter chapter={chapter} reducedMotion />
            </div>
          ))}
          <div className="relative flex min-h-screen items-center justify-center overflow-hidden">
            <HeroFinalStatement reducedMotion />
          </div>
        </section>
      </HeroTiltProvider>
    );
  }

  return (
    <HeroTiltProvider>
      <section
        id="top"
        ref={wrapperRef}
        aria-label="The UNNAGGI production journey"
        className="relative h-[calc(var(--hero-vh-per-chapter)*12)]"
      >
        <div className="sticky top-0 h-screen w-full overflow-hidden bg-navy">
          {HERO_CHAPTERS.map((chapter, i) => (
            <HeroChapter
              key={chapter.id}
              chapter={chapter}
              ref={(el) => {
                chapterRefs.current[i] = el;
              }}
            />
          ))}
          <HeroFinalStatement ref={closingRef} />
        </div>
      </section>
      <HeroProgressRail visible={heroInView} />
    </HeroTiltProvider>
  );
}
