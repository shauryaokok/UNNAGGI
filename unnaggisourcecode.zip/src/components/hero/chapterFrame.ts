/**
 * Imperative, DOM-cached scrub engine shared by every chapter. One master
 * ScrollTrigger (see Hero.tsx) drives all 11 chapters + the closing statement —
 * this avoids creating/tearing down a GSAP timeline per chapter and keeps the
 * per-scroll-tick work to plain style writes on a pre-collected node list.
 *
 * Overlay authors opt into the generic "settle into place" reveal by adding
 * `data-reveal` (+ optional data-reveal-at/-duration/-x/-y/-rotate/-scale) to any
 * element — no bespoke JS required for the common case. Chapter-specific motion
 * beyond this (aperture blades, kinetic type, etc.) reads the `--chapter-progress`
 * CSS custom property this engine writes on the chapter root every tick.
 */

interface RevealNode {
  el: HTMLElement;
  start: number;
  duration: number;
  x: number;
  y: number;
  rotate: number;
  scale: number;
}

export interface ChapterNodes {
  root: HTMLElement;
  headline: HTMLElement | null;
  microcopy: HTMLElement | null;
  reveals: RevealNode[];
}

export function collectChapterNodes(root: HTMLElement): ChapterNodes {
  const reveals = Array.from(
    root.querySelectorAll<HTMLElement>("[data-reveal]")
  ).map((el, i) => ({
    el,
    start: el.dataset.revealAt ? Number(el.dataset.revealAt) : 0.08 + i * 0.03,
    duration: el.dataset.revealDuration ? Number(el.dataset.revealDuration) : 0.3,
    x: el.dataset.revealX ? Number(el.dataset.revealX) : 0,
    y: el.dataset.revealY ? Number(el.dataset.revealY) : 0,
    rotate: el.dataset.revealRotate ? Number(el.dataset.revealRotate) : 0,
    scale: el.dataset.revealScale ? Number(el.dataset.revealScale) : 1,
  }));

  return {
    root,
    headline: root.querySelector<HTMLElement>('[data-role="headline-fill"]'),
    microcopy: root.querySelector<HTMLElement>('[data-role="microcopy"]'),
    reveals,
  };
}

function remap(
  value: number,
  inMin: number,
  inMax: number,
  outMin = 0,
  outMax = 1
) {
  if (inMax === inMin) return value < inMin ? outMin : outMax;
  const t = Math.min(1, Math.max(0, (value - inMin) / (inMax - inMin)));
  return outMin + t * (outMax - outMin);
}

/** local is the chapter's own 0-1 progress: 0 = not yet entered, 1 = fully exited. */
export function applyChapterFrame(nodes: ChapterNodes, local: number) {
  const clamped = Math.min(1, Math.max(0, local));
  nodes.root.style.setProperty("--chapter-progress", String(clamped));

  const alpha =
    clamped < 0.12
      ? clamped / 0.12
      : clamped > 0.88
        ? (1 - clamped) / 0.12
        : 1;
  nodes.root.style.opacity = String(alpha);
  nodes.root.style.visibility = alpha > 0.01 ? "visible" : "hidden";
  nodes.root.style.pointerEvents = alpha > 0.5 ? "auto" : "none";

  if (nodes.headline) {
    const t = remap(clamped, 0.04, 0.32);
    nodes.headline.style.clipPath = `inset(0 ${(1 - t) * 100}% 0 0)`;
  }

  if (nodes.microcopy) {
    const t = remap(clamped, 0.12, 0.34);
    nodes.microcopy.style.opacity = String(t);
    nodes.microcopy.style.transform = `translateY(${(1 - t) * 16}px)`;
  }

  for (const reveal of nodes.reveals) {
    const t = remap(clamped, reveal.start, reveal.start + reveal.duration);
    reveal.el.style.opacity = String(t);
    const inv = 1 - t;
    const scale = reveal.scale + (1 - reveal.scale) * t;
    reveal.el.style.transform = `translate(${reveal.x * inv}px, ${reveal.y * inv}px) rotate(${reveal.rotate * inv}deg) scale(${scale})`;
  }
}

export function resetChapterFrame(nodes: ChapterNodes) {
  nodes.root.style.opacity = "0";
  nodes.root.style.visibility = "hidden";
  if (nodes.headline) nodes.headline.style.clipPath = "inset(0 100% 0 0)";
  if (nodes.microcopy) {
    nodes.microcopy.style.opacity = "0";
    nodes.microcopy.style.transform = "translateY(16px)";
  }
  for (const reveal of nodes.reveals) {
    reveal.el.style.opacity = "0";
  }
}
