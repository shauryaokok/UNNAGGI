"use client";

import {
  createContext,
  useContext,
  useEffect,
  type ReactNode,
} from "react";
import { useMotionValue, useSpring, type MotionValue } from "motion/react";
import { isTouchDevice, prefersReducedMotion } from "@/lib/device";

interface TiltValue {
  rotateX: MotionValue<number>;
  rotateY: MotionValue<number>;
}

const TiltContext = createContext<TiltValue | null>(null);

/**
 * One shared mouse-follow tilt for the whole reel — a single listener instead of
 * one per chapter. Decoupled from the GSAP scroll-scrub loop entirely.
 */
export function HeroTiltProvider({ children }: { children: ReactNode }) {
  const rotateX = useMotionValue(0);
  const rotateY = useMotionValue(0);
  const springX = useSpring(rotateX, { stiffness: 60, damping: 20 });
  const springY = useSpring(rotateY, { stiffness: 60, damping: 20 });

  useEffect(() => {
    if (isTouchDevice() || prefersReducedMotion()) return;

    const handleMove = (event: MouseEvent) => {
      const relX = (event.clientX / window.innerWidth - 0.5) * 2;
      const relY = (event.clientY / window.innerHeight - 0.5) * 2;
      rotateY.set(relX * 3);
      rotateX.set(relY * -3);
    };
    window.addEventListener("mousemove", handleMove);
    return () => window.removeEventListener("mousemove", handleMove);
  }, [rotateX, rotateY]);

  return (
    <TiltContext.Provider value={{ rotateX: springX, rotateY: springY }}>
      {children}
    </TiltContext.Provider>
  );
}

export function useHeroTilt() {
  const ctx = useContext(TiltContext);
  if (!ctx) throw new Error("useHeroTilt must be used within HeroTiltProvider");
  return ctx;
}
