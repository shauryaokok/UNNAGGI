"use client";

import { HERO_CHAPTERS } from "@/content/hero.content";
import { useProgress } from "./progressStore";

interface HeroProgressRailProps {
  /** Only relevant while the pinned Hero is actually in the viewport. */
  visible: boolean;
}

/** The timecode-style "CH. 04 / 11 — LIGHTS" HUD readout, viewport-fixed while the Hero is in view. */
export function HeroProgressRail({ visible }: HeroProgressRailProps) {
  const activeIndex = useProgress("hero:active");
  const total = HERO_CHAPTERS.length;
  const isClosing = activeIndex >= total;
  const chapter = HERO_CHAPTERS[Math.min(activeIndex, total - 1)];
  const label = isClosing ? "Final Film" : chapter.headline;
  const displayIndex = isClosing ? total : chapter.index;

  return (
    <div
      aria-hidden="true"
      className={`pointer-events-none fixed bottom-8 left-8 z-20 font-mono text-[10px] uppercase tracking-[0.32em] text-ivory/50 transition-opacity duration-500 sm:bottom-10 sm:left-10 ${
        visible ? "opacity-100" : "opacity-0"
      }`}
    >
      Ch. {String(displayIndex).padStart(2, "0")} / {String(total).padStart(2, "0")}
      <span className="mx-2 text-gold">—</span>
      {label}
    </div>
  );
}
