import { forwardRef } from "react";
import { HERO_CLOSING } from "@/content/hero.content";
import { MagneticButton } from "@/components/ui/MagneticButton";
import { ScrollCue } from "@/components/ui/ScrollCue";
import { LightingLayer } from "./layers/LightingLayer";
import { NoiseLayer } from "./layers/NoiseLayer";
import { InteractionLayer } from "./layers/InteractionLayer";

/**
 * The reel's closing frame. The tagline reveals word-by-word via the same
 * generic `data-reveal` stagger every chapter uses (rather than a one-shot
 * SplitText animation) so it stays perfectly scrub-reversible with the rest
 * of the reel — scrolling back up genuinely un-reveals it.
 */
interface HeroFinalStatementProps {
  reducedMotion?: boolean;
}

export const HeroFinalStatement = forwardRef<HTMLDivElement, HeroFinalStatementProps>(
  function HeroFinalStatement({ reducedMotion }, ref) {
    const words = HERO_CLOSING.headline.split(" ");

    return (
      <div
        ref={ref}
        data-chapter-id="closing"
        className={reducedMotion ? "absolute inset-0 opacity-100" : "absolute inset-0 opacity-0"}
      >
        <div className="absolute inset-0 bg-navy" />
        <LightingLayer mood="warm" />
        <NoiseLayer />

        <div className="pointer-events-none absolute inset-0 flex flex-col items-center justify-center gap-8 px-6 text-center">
          <h2 className="flex flex-wrap justify-center gap-x-4 font-display text-[9vw] font-light leading-[1.05] text-ivory sm:text-[5vw]">
            {words.map((word, i) => (
              <span key={`${word}-${i}`} className="overflow-hidden">
                <span
                  data-reveal
                  data-reveal-at={0.15 + i * 0.08}
                  data-reveal-duration={0.3}
                  data-reveal-y={40}
                  className="inline-block"
                >
                  {word}
                </span>
              </span>
            ))}
          </h2>
          <p
            data-role="microcopy"
            className="font-sans text-sm text-ivory/70 sm:text-base"
          >
            {HERO_CLOSING.microcopy}
          </p>
        </div>

        <InteractionLayer>
          <div className="pointer-events-none absolute inset-x-0 bottom-16 flex flex-col items-center gap-10">
            <MagneticButton
              cursorLabel="Enter"
              className="pointer-events-auto border border-gold/60 px-8 py-4 font-mono text-xs uppercase tracking-[0.3em] text-ivory transition-colors duration-300 hover:bg-gold/10"
            >
              {HERO_CLOSING.ctaLabel}
            </MagneticButton>
            <div className="pointer-events-auto">
              <ScrollCue />
            </div>
          </div>
        </InteractionLayer>
      </div>
    );
  }
);
