"use client";

import { useSyncExternalStore } from "react";

/**
 * Tiny keyed external store for scroll-derived values that need to reach React
 * (progress rail, the R3F aperture scene) without funnelling every scrub tick
 * through a re-rendering parent component.
 */
const values = new Map<string, number>();
const listeners = new Map<string, Set<() => void>>();

export function setProgress(key: string, value: number) {
  values.set(key, value);
  listeners.get(key)?.forEach((listener) => listener());
}

export function getProgress(key: string) {
  return values.get(key) ?? 0;
}

function subscribe(key: string) {
  return (listener: () => void) => {
    if (!listeners.has(key)) listeners.set(key, new Set());
    const set = listeners.get(key)!;
    set.add(listener);
    return () => set.delete(listener);
  };
}

export function useProgress(key: string) {
  return useSyncExternalStore(subscribe(key), () => getProgress(key), () => 0);
}
