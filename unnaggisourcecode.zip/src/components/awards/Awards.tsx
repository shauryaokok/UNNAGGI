import { AWARDS } from "@/content/awards.content";
import { Marquee } from "@/components/ui/Marquee";
import { SectionHeading } from "@/components/ui/SectionHeading";
import { useRevealOnScroll } from "@/hooks/useRevealOnScroll";

function LaurelIcon() {
  return (
    <svg
      viewBox="0 0 24 24"
      className="h-5 w-5 shrink-0 text-gold"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.2"
      aria-hidden="true"
    >
      <path d="M12 3v18" />
      <path d="M12 6c-2 2-5 2-7 0" />
      <path d="M12 10c-2 2-5 2-7 0" />
      <path d="M12 14c-2 2-5 2-7 0" />
      <path d="M12 6c2 2 5 2 7 0" />
      <path d="M12 10c2 2 5 2 7 0" />
      <path d="M12 14c2 2 5 2 7 0" />
    </svg>
  );
}

export function Awards() {
  const ref = useRevealOnScroll<HTMLElement>();

  return (
    <section
      ref={ref}
      className="relative overflow-hidden bg-almost-black py-32 lg:py-40"
    >
      <div className="mx-auto max-w-6xl px-8 sm:px-10">
        <SectionHeading
          eyebrow="Recognition"
          title="A few of the rooms that noticed."
          align="center"
        />
      </div>

      <div className="mt-16" data-reveal>
        <Marquee durationSeconds={38}>
          {AWARDS.map((award) => (
            <div key={award.id} className="flex items-center gap-4 px-10">
              <LaurelIcon />
              <div className="flex flex-col">
                <span className="font-display text-lg font-light text-ivory sm:text-xl">
                  {award.title}
                </span>
                <span className="font-mono text-[10px] uppercase tracking-[0.25em] text-ivory/50">
                  {award.organization} — {award.year}
                </span>
              </div>
            </div>
          ))}
        </Marquee>
      </div>
    </section>
  );
}
