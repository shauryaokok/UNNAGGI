"use client";

import { useEffect, useRef, useState } from "react";
import { LOADER_CONFIG } from "@/content/loader.content";
import { LoaderCountdown } from "./LoaderCountdown";
import { LoaderWordmark } from "./LoaderWordmark";
import { LoaderWords } from "./LoaderWords";
import { LoaderShutter } from "./LoaderShutter";
import { useLoaderTimeline } from "./useLoaderTimeline";
import { MagneticButton } from "@/components/ui/MagneticButton";
import { UnnaggiMark } from "@/components/brand/UnnaggiMark";
import { useCursor } from "@/components/cursor/CursorProvider";

interface LoaderProps {
  onComplete: () => void;
}

export function Loader({ onComplete }: LoaderProps) {
  const [hidden, setHidden] = useState(false);
  const [skippable, setSkippable] = useState(false);
  const { resetCursor } = useCursor();

  const root = useRef<HTMLDivElement>(null);
  const dial = useRef<SVGCircleElement>(null);
  const percent = useRef<HTMLSpanElement>(null);
  const wordmarkFill = useRef<HTMLSpanElement>(null);
  const words = useRef<(HTMLSpanElement | null)[]>([]);
  const shutterTop = useRef<HTMLDivElement>(null);
  const shutterBottom = useRef<HTMLDivElement>(null);

  const { skip } = useLoaderTimeline(
    { root, dial, percent, wordmarkFill, words, shutterTop, shutterBottom },
    LOADER_CONFIG.minDurationMs,
    () => {
      // A hovered magnetic button never fires mouseleave when its element
      // unmounts, so the cursor can get stuck expanded on its last label
      // (e.g. "Skip") — force it back to default as this full-screen takeover goes away.
      resetCursor();
      setHidden(true);
      onComplete();
    }
  );

  useEffect(() => {
    const timer = setTimeout(() => setSkippable(true), 1200);
    return () => clearTimeout(timer);
  }, []);

  useEffect(() => {
    if (!skippable) return;
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape" || event.key === "Enter") skip();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [skippable, skip]);

  if (hidden) return null;

  return (
    <div
      ref={root}
      role="dialog"
      aria-label={`Loading ${LOADER_CONFIG.wordmark}`}
      aria-modal="true"
      className="fixed inset-0 z-[90] flex items-center justify-center bg-navy"
    >
      <LoaderCountdown dialRef={dial} percentRef={percent}>
        <UnnaggiMark className="h-8 w-auto text-gold sm:h-10" />
        <LoaderWordmark word={LOADER_CONFIG.wordmark} fillRef={wordmarkFill} />
        <LoaderWords words={LOADER_CONFIG.cyclingWords} wordRefs={words} />
      </LoaderCountdown>

      {skippable && (
        <MagneticButton
          onClick={skip}
          cursorLabel="Skip"
          className="absolute bottom-10 right-10 font-mono text-[11px] uppercase tracking-[0.3em] text-ivory/50 transition-colors duration-300 hover:text-ivory"
        >
          Skip
        </MagneticButton>
      )}

      <LoaderShutter topRef={shutterTop} bottomRef={shutterBottom} />
    </div>
  );
}
