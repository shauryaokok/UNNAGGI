"use client";

import type { RefObject } from "react";

interface LoaderShutterProps {
  topRef: RefObject<HTMLDivElement | null>;
  bottomRef: RefObject<HTMLDivElement | null>;
}

/** The recurring shutter motif — reused at Hero chapter transitions too. */
export function LoaderShutter({ topRef, bottomRef }: LoaderShutterProps) {
  return (
    <>
      <div
        ref={topRef}
        aria-hidden="true"
        className="pointer-events-none fixed inset-x-0 top-0 z-[95] h-1/2 origin-top scale-y-0 bg-almost-black"
      />
      <div
        ref={bottomRef}
        aria-hidden="true"
        className="pointer-events-none fixed inset-x-0 bottom-0 z-[95] h-1/2 origin-bottom scale-y-0 bg-almost-black"
      />
    </>
  );
}
