"use client";

import { useCallback, useRef, type RefObject } from "react";
import { useGSAP } from "@gsap/react";
import { gsap, ScrollTrigger } from "@/lib/gsap";
import { gsapEase } from "@/lib/motion-tokens";
import { useLenis } from "@/lib/lenis";
import { prefersReducedMotion } from "@/lib/device";
import { LOADER_DIAL_CIRCUMFERENCE } from "./LoaderCountdown";

export interface LoaderTimelineRefs {
  root: RefObject<HTMLDivElement | null>;
  dial: RefObject<SVGCircleElement | null>;
  percent: RefObject<HTMLSpanElement | null>;
  wordmarkFill: RefObject<HTMLSpanElement | null>;
  words: RefObject<(HTMLSpanElement | null)[]>;
  shutterTop: RefObject<HTMLDivElement | null>;
  shutterBottom: RefObject<HTMLDivElement | null>;
}

export function useLoaderTimeline(
  refs: LoaderTimelineRefs,
  minDurationMs: number,
  onComplete: () => void
) {
  const lenis = useLenis();
  const doneRef = useRef(false);
  const skipRef = useRef<() => void>(() => {});

  const finish = useCallback(() => {
    if (doneRef.current) return;
    doneRef.current = true;
    document.body.classList.remove("is-locked");
    lenis?.start();
    requestAnimationFrame(() => ScrollTrigger.refresh());
    try {
      sessionStorage.setItem("unnaggi-loader-seen", "1");
    } catch {
      /* sessionStorage unavailable — non-fatal, loader just replays. */
    }
    onComplete();
  }, [lenis, onComplete]);

  useGSAP(
    () => {
      if (!refs.root.current) return;
      document.body.classList.add("is-locked");

      const setDial = (value: number) => {
        if (refs.dial.current) {
          refs.dial.current.style.strokeDashoffset = String(
            LOADER_DIAL_CIRCUMFERENCE * (1 - value / 100)
          );
        }
        if (refs.percent.current) {
          refs.percent.current.textContent = `${Math.round(value)}%`;
        }
      };

      if (prefersReducedMotion()) {
        setDial(100);
        gsap.to(refs.root.current, {
          autoAlpha: 0,
          duration: 0.4,
          delay: 0.1,
          onComplete: finish,
        });
        skipRef.current = finish;
        return;
      }

      setDial(0);
      const progress = { value: 0 };
      const wordEls = (refs.words.current ?? []).filter(
        (el): el is HTMLSpanElement => !!el
      );

      let outroTl: gsap.core.Timeline | null = null;

      const buildOutro = () => {
        if (outroTl) return outroTl;
        outroTl = gsap.timeline({ onComplete: finish });
        outroTl
          .to(progress, {
            value: 100,
            duration: 0.4,
            ease: gsapEase.reveal,
            onUpdate: () => setDial(progress.value),
          })
          .to(
            refs.wordmarkFill.current,
            { clipPath: "inset(0 0% 0 0)", duration: 0.6, ease: gsapEase.cinematic },
            "<"
          )
          .to(
            [refs.shutterTop.current, refs.shutterBottom.current],
            { scaleY: 1, duration: 0.6, ease: gsapEase.shutter },
            "+=0.15"
          )
          .to(
            [refs.shutterTop.current, refs.shutterBottom.current],
            { scaleY: 0, duration: 0.6, ease: gsapEase.shutter },
            "+=0.1"
          );
        return outroTl;
      };

      const introTl = gsap.timeline();
      introTl.to(
        progress,
        {
          value: 92,
          duration: minDurationMs / 1000,
          ease: gsapEase.reveal,
          onUpdate: () => setDial(progress.value),
        },
        0
      );

      const slot = minDurationMs / 1000 / Math.max(wordEls.length, 1);
      wordEls.forEach((el, i) => {
        const start = i * slot;
        introTl
          .to(el, { autoAlpha: 1, duration: 0.15 }, start)
          .to(el, { autoAlpha: 0, duration: 0.15 }, start + slot - 0.15);
      });

      const fontsReady =
        typeof document !== "undefined" && document.fonts
          ? document.fonts.ready
          : Promise.resolve();

      introTl.eventCallback("onComplete", () => {
        fontsReady.then(() => {
          if (!doneRef.current) buildOutro();
        });
      });

      skipRef.current = () => {
        if (doneRef.current) return;
        introTl.progress(1);
        buildOutro().progress(1);
      };
    },
    { scope: refs.root, dependencies: [minDurationMs] }
  );

  return { skip: () => skipRef.current() };
}
