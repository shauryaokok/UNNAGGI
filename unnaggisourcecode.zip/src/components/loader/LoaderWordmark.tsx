"use client";

import type { RefObject } from "react";

interface LoaderWordmarkProps {
  word: string;
  fillRef: RefObject<HTMLSpanElement | null>;
}

/**
 * Two stacked copies of the wordmark: a faint ghost (always visible) and a solid
 * fill revealed by a GSAP-driven clip-path wipe — reads as the mark "drawing on".
 */
export function LoaderWordmark({ word, fillRef }: LoaderWordmarkProps) {
  return (
    <div className="relative select-none whitespace-nowrap font-display text-[13vw] font-light leading-none tracking-tight sm:text-[6.5vw]">
      <span aria-hidden="true" className="text-ivory/15">
        {word}
      </span>
      <span
        ref={fillRef}
        aria-hidden="true"
        className="absolute inset-0 text-ivory"
        style={{ clipPath: "inset(0 100% 0 0)" }}
      >
        {word}
      </span>
    </div>
  );
}
