"use client";

import type { ReactNode, RefObject } from "react";

export const LOADER_DIAL_RADIUS = 124;
export const LOADER_DIAL_CIRCUMFERENCE = 2 * Math.PI * LOADER_DIAL_RADIUS;

interface LoaderCountdownProps {
  dialRef: RefObject<SVGCircleElement | null>;
  percentRef: RefObject<HTMLSpanElement | null>;
  children: ReactNode;
}

const TICK_COUNT = 12;

/** A reinterpreted academy countdown leader: a circular wipe standing in for "3...2...1". */
export function LoaderCountdown({
  dialRef,
  percentRef,
  children,
}: LoaderCountdownProps) {
  const center = 140;
  // Rounded to 2dp: raw trig output can differ in the last float digit between
  // the server and browser JS engines, which trips a hydration mismatch.
  const round = (n: number) => Math.round(n * 100) / 100;
  const ticks = Array.from({ length: TICK_COUNT }, (_, i) => {
    const angle = (i / TICK_COUNT) * Math.PI * 2;
    const outer = LOADER_DIAL_RADIUS + 10;
    const inner = LOADER_DIAL_RADIUS + (i % 3 === 0 ? 2 : 5);
    return {
      x1: round(center + outer * Math.cos(angle)),
      y1: round(center + outer * Math.sin(angle)),
      x2: round(center + inner * Math.cos(angle)),
      y2: round(center + inner * Math.sin(angle)),
    };
  });

  return (
    <div className="relative flex h-[clamp(220px,32vw,300px)] w-[clamp(220px,32vw,300px)] items-center justify-center">
      <svg
        viewBox="0 0 280 280"
        className="absolute inset-0 -rotate-90"
        aria-hidden="true"
      >
        <circle
          cx={center}
          cy={center}
          r={LOADER_DIAL_RADIUS}
          stroke="rgba(245,242,235,0.14)"
          strokeWidth={1}
          fill="none"
        />
        <circle
          ref={dialRef}
          cx={center}
          cy={center}
          r={LOADER_DIAL_RADIUS}
          stroke="var(--color-gold)"
          strokeWidth={1.5}
          strokeLinecap="round"
          fill="none"
          strokeDasharray={LOADER_DIAL_CIRCUMFERENCE}
          strokeDashoffset={LOADER_DIAL_CIRCUMFERENCE}
        />
        {ticks.map((tick, i) => (
          <line
            key={i}
            x1={tick.x1}
            y1={tick.y1}
            x2={tick.x2}
            y2={tick.y2}
            stroke="rgba(245,242,235,0.3)"
            strokeWidth={1}
          />
        ))}
      </svg>

      <div className="relative flex flex-col items-center gap-5">
        {children}
        <span
          role="status"
          aria-live="polite"
          ref={percentRef}
          className="font-mono text-xs tracking-[0.3em] text-soft-gray"
        >
          0%
        </span>
      </div>
    </div>
  );
}
