"use client";

import type { RefObject } from "react";

interface LoaderWordsProps {
  words: string[];
  wordRefs: RefObject<(HTMLSpanElement | null)[]>;
}

/** Cycling word stack, foreshadowing the Hero's chapters. */
export function LoaderWords({ words, wordRefs }: LoaderWordsProps) {
  return (
    <div
      aria-hidden="true"
      className="relative h-4 w-40 font-mono text-xs uppercase tracking-[0.4em] text-gold"
    >
      {words.map((word, i) => (
        <span
          key={word}
          ref={(el) => {
            wordRefs.current[i] = el;
          }}
          className="absolute inset-0 flex items-center justify-center opacity-0"
        >
          {word}
        </span>
      ))}
    </div>
  );
}
