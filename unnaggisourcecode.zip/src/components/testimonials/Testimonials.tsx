"use client";

import { useEffect, useState } from "react";
import { AnimatePresence, motion } from "motion/react";
import { TESTIMONIALS } from "@/content/testimonials.content";
import { useRevealOnScroll } from "@/hooks/useRevealOnScroll";
import { framerEase } from "@/lib/motion-tokens";

export function Testimonials() {
  const ref = useRevealOnScroll<HTMLElement>();
  const [index, setIndex] = useState(0);

  useEffect(() => {
    const timer = setInterval(
      () => setIndex((i) => (i + 1) % TESTIMONIALS.length),
      6500
    );
    return () => clearInterval(timer);
  }, []);

  const current = TESTIMONIALS[index];

  return (
    <section
      ref={ref}
      className="relative bg-navy px-8 py-32 sm:px-10 lg:py-40"
    >
      <div className="mx-auto flex max-w-4xl flex-col items-center text-center">
        <span
          data-reveal
          className="font-mono text-[11px] uppercase tracking-[0.4em] text-gold"
        >
          Client Words
        </span>

        <div className="relative mt-10 min-h-[220px] w-full sm:min-h-[180px]">
          <AnimatePresence mode="wait">
            <motion.figure
              key={current.id}
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -16 }}
              transition={{ duration: 0.6, ease: framerEase.cinematic }}
            >
              <blockquote className="font-display text-2xl font-light italic leading-relaxed text-ivory sm:text-4xl">
                &ldquo;{current.quote}&rdquo;
              </blockquote>
              <figcaption className="mt-6 font-mono text-xs uppercase tracking-[0.25em] text-ivory/50">
                {current.name} — {current.role}
              </figcaption>
            </motion.figure>
          </AnimatePresence>
        </div>

        <div className="mt-10 flex items-center gap-3">
          {TESTIMONIALS.map((testimonial, i) => (
            <button
              key={testimonial.id}
              type="button"
              onClick={() => setIndex(i)}
              aria-label={`Show testimonial from ${testimonial.name}`}
              className={`h-1.5 rounded-full transition-all duration-500 ${
                i === index ? "w-8 bg-gold" : "w-1.5 bg-ivory/25"
              }`}
            />
          ))}
        </div>
      </div>
    </section>
  );
}
