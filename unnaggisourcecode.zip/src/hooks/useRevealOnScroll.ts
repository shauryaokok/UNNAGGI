"use client";

import { useRef, type RefObject } from "react";
import { useGSAP } from "@gsap/react";
import { gsap, ScrollTrigger } from "@/lib/gsap";
import { gsapEase } from "@/lib/motion-tokens";

interface RevealOptions {
  y?: number;
  stagger?: number;
  duration?: number;
  start?: string;
  selector?: string;
}

/**
 * Generic "reveal once when scrolled into view" engine for every non-pinned
 * section below the Hero. Mark any child `data-reveal` and it fades/rises in,
 * staggered, the first time it crosses the trigger line — no bespoke GSAP
 * wiring needed per section.
 */
export function useRevealOnScroll<T extends HTMLElement = HTMLDivElement>(
  options: RevealOptions = {}
): RefObject<T | null> {
  const ref = useRef<T>(null);
  const selector = options.selector ?? "[data-reveal]";

  useGSAP(
    () => {
      if (!ref.current) return;
      const targets = gsap.utils.toArray<HTMLElement>(
        ref.current.querySelectorAll(selector)
      );
      if (!targets.length) return;

      gsap.set(targets, { autoAlpha: 0, y: options.y ?? 32 });

      ScrollTrigger.batch(targets, {
        start: options.start ?? "top 85%",
        once: true,
        onEnter: (batch) => {
          gsap.to(batch, {
            autoAlpha: 1,
            y: 0,
            duration: options.duration ?? 0.9,
            ease: gsapEase.cinematic,
            stagger: options.stagger ?? 0.08,
          });
        },
      });
    },
    { scope: ref }
  );

  return ref;
}
